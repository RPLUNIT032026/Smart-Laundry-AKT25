# Wash Wash Laundry — Paket Portable

## Cara menjalankan
1. Ekstrak ZIP ini terlebih dahulu (jangan membuka index.html dari dalam ZIP).
2. Buka `index.html` dengan Chrome atau Edge.
3. File `index.html` sudah dibuat mandiri: CSS, JavaScript, logo, dan ikon utama tertanam di dalamnya. Karena itu, halaman utama tidak bergantung pada alamat folder `assets` saat dibuka melalui file lokal/`content://` di Android.
4. Folder `assets/` tetap disertakan dengan file sumber aslinya untuk pemeriksaan dan pengumpulan tugas.

## Catatan
- Aplikasi menyimpan data di penyimpanan browser perangkat masing-masing (localStorage). Data tidak otomatis tersinkron antara HP dan laptop/perangkat lain.
- Untuk menjalankan dashboard secara lokal, buka file `index.html` setelah ZIP diekstrak.
- Jika browser Android menolak membuka file HTML, gunakan opsi File Manager > Bagikan/Buka dengan > Chrome, atau pindahkan hasil ekstrak ke folder Download terlebih dahulu.
