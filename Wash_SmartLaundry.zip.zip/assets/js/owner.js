'use strict';
/* Fitur Owner: dashboard, laporan, layanan, mesin (konfigurasi + rekap), kinerja, manajemen karyawan */
const paidOrders=()=>db.orders.filter(o=>o.paid&&o.status!=='Dibatalkan');
const payLabel=o=>o.status==='Dibatalkan'?'<span class="badge b-x">Dibatalkan</span>':o.paid?`<span class="badge b-rdy">Lunas · ${o.pay==='qris'?'QRIS':'Tunai'}</span>`:'<span class="badge b-wait">Belum bayar</span>';
function txTable(list){return list.length?`<table><tr><th>ID Transaksi</th><th>Pelanggan</th><th>Tanggal</th><th>Layanan</th><th>Berat</th><th>Total</th><th>Pembayaran</th></tr>${list.map(o=>`<tr><td><a class="id" data-act="detail" data-id="${o.n}">TRX-${String(o.n).padStart(4,'0')}</a></td><td>${esc(o.cust)}</td><td>${fmtD(o.t)}</td><td>${esc(o.sname)}</td><td>${o.kg} kg</td><td>${rp(o.total)}</td><td>${payLabel(o)}</td></tr>`).join('')}</table>`:empty('Belum ada transaksi','Laporan terisi setelah pelanggan membuat pesanan dan membayar.')}
function csvDownload(list){
 const r=[['ID','Pelanggan','Tanggal','Layanan','Berat(kg)','Total','Status','Metode','Lunas']].concat(list.map(o=>[oid(o.n),o.cust,fmtD(o.t),o.sname,o.kg,o.total,o.status,o.pay==='qris'?'QRIS':'Tunai',o.paid?'ya':'tidak']));
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+r.map(x=>x.map(c=>`"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n')],{type:'text/csv'}));a.download='laporan-washwash.csv';a.click()}
PAGES.owner.dashboard=u=>{
 const rev=paidOrders().reduce((a,o)=>a+o.total,0),act=db.machines.filter(m=>m.active),run=act.filter(m=>m.orderId).length,done=db.orders.filter(o=>o.status==='Telah Diambil').length;
 const handled=db.orders.filter(o=>o.handledBy),ok=handled.filter(o=>['Siap Diambil','Telah Diambil'].includes(o.status)).length,perf=handled.length?Math.round(ok/handled.length*100)+'%':'0%';
 const days=[...Array(7)].map((_,i)=>{const d=new Date(Date.now()-(6-i)*864e5);return{k:d.toDateString(),l:d.getDate()+' '+d.toLocaleDateString('id-ID',{month:'short'})}});
 const vals=days.map(d=>paidOrders().filter(o=>new Date(o.paidAt||o.t).toDateString()===d.k).reduce((a,o)=>a+o.total,0)),mx=Math.max(...vals,1);
 return `<div class="between wrap"><div><h2 style="font-size:26px">Bisnis bersih, hasil lebih.</h2><p class="mut">Ringkasan performa ${esc(db.settings.biz_name||'Wash Wash Laundry')} dalam satu pandangan.</p></div><div class="shiftbox"><span class="ic">📅</span><div><b>${today()}</b><small>Data real-time</small></div></div></div>
 <div class="stats">${statCard('Total Pendapatan',rp(rev),'dari pesanan lunas','💰')}${statCard('Pesanan Selesai',done,'telah diambil pelanggan','✓')}${statCard('Utilisasi Mesin IoT',act.length?Math.round(run/act.length*100)+'%':'0%',run+' dari '+act.length+' mesin sedang beroperasi','◎')}${statCard('Kinerja Petugas',perf,'pesanan selesai diproses','▤')}</div>
 <div class="cols"><div class="card"><h3>Pendapatan harian</h3><div class="sub">Total pembayaran 7 hari terakhir (dalam rupiah).</div>${rev?'':'<div class="mut small">Belum ada pendapatan. Uang masuk setelah pelanggan membayar.</div>'}<div class="chart">${vals.map((v,i)=>`<div class="${i===6?'today':''}"><span>${v?rp(v).replace('Rp',''):''}</span><i style="height:${v/mx*80}%"></i>${days[i].l}</div>`).join('')}</div></div>${logCard()}</div>
 <div class="card"><div class="between wrap"><div><h3>Laporan transaksi</h3><div class="sub">Transaksi terbaru dalam periode terpilih</div></div><button class="btn" data-act="csv" ${db.orders.length?'':'disabled'}>⭳ Export Laporan</button></div><div class="tbl">${txTable(db.orders.slice().sort((a,b)=>b.n-a.n).slice(0,4))}</div>${db.orders.length>4?'<div style="margin-top:10px"><a data-nav="laporan">Lihat semua transaksi →</a></div>':''}</div>`};
let repDays=7;
PAGES.owner.laporan=()=>{
 const since=repDays?Date.now()-repDays*864e5:0,list=db.orders.filter(o=>o.t>=since).sort((a,b)=>b.n-a.n),sum=list.filter(o=>o.paid&&o.status!=='Dibatalkan').reduce((a,o)=>a+o.total,0);
 return `<div class="card"><div class="between wrap"><div><h3>Laporan transaksi</h3><div class="sub">${list.length} transaksi • pendapatan lunas ${rp(sum)}</div></div>
 <div class="between" style="gap:8px"><div class="seg">${[[7,'7 hari'],[30,'30 hari'],[0,'Semua']].map(p=>`<button class="${repDays===p[0]?'on':''}" data-act="period" data-id="${p[0]}">${p[1]}</button>`).join('')}</div><button class="btn" data-act="csv" ${list.length?'':'disabled'}>⭳ Export Laporan</button></div></div>
 <div class="tbl">${txTable(list)}</div></div>`};
ACT.period=id=>{repDays=+id;route()};
ACT.csv=()=>{const since=repDays&&location.hash.includes('laporan')?Date.now()-repDays*864e5:0;csvDownload(db.orders.filter(o=>o.t>=since).sort((a,b)=>b.n-a.n))};

/* ---- layanan ---- */
PAGES.owner.layanan=()=>`<div class="between wrap"><div><h2 style="font-size:24px">Kelola layanan</h2><p class="mut">Atur paket dan tarif laundry sesuai kebutuhan pelanggan.</p></div><button class="btn" data-act="svcnew">＋ Tambah Layanan Baru</button></div>
 <div class="info-bar"><b>Laundry praktis, tanpa setrika.</b> Tarif dihitung per kilogram. Pilih cuci kering atau cuci basah sesuai kebutuhan pelanggan. <span class="badge">${db.services.filter(s=>s.on).length} layanan aktif</span></div>
 ${db.services.length?`<div class="svc">${db.services.map(s=>`<div class="card" style="${s.on?'':'opacity:.6'}"><div class="between"><small class="mut">${esc(s.tag)}</small><span class="badge ${s.on?'b-rdy':''}">${s.on?'Aktif':'Nonaktif'}</span></div><h3 style="font-size:22px">${esc(s.name)}</h3><p class="mut small">${esc(s.desc)}</p>
 <div class="p">${rp(s.price)}<small> / kg</small></div><small class="mut">Estimasi selesai ${esc(s.est)}</small><ul>${s.feat.map(f=>`<li>${esc(f)}</li>`).join('')}</ul>
 <div class="acts"><button class="btn out sm" data-act="svc" data-id="${s.id}">✎ Edit Harga</button><button class="btn ghost sm" data-act="tog" data-id="${s.id}">${s.on?'Nonaktifkan':'Aktifkan'}</button></div></div>`).join('')}</div>`:`<div class="card">${empty('Belum ada layanan','Tambahkan layanan pertama.')}</div>`}
 <div class="cols"><div class="card"><h3>Ketentuan layanan</h3><div class="sub">Informasi yang digunakan petugas saat membuat pesanan.</div><table class="kv">${[['Satuan tarif','Per kilogram (kg)'],['Setrika','Tidak termasuk pada semua paket'],['Penimbangan','Berat aktual saat penerimaan'],['Perubahan tarif','Berlaku untuk pesanan baru']].map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td></tr>`).join('')}</table></div>
 <div class="card note-card"><h3>Satu tarif, semua tersinkron.</h3><p class="small">Perubahan harga otomatis tersedia di halaman penerimaan pesanan petugas. Pesanan yang sudah dibuat tetap menggunakan tarif awal.</p></div></div>`;
ACT.svcnew=()=>svcModal();
ACT.svc=id=>svcModal(id);
ACT.tog=id=>act('togsvc',{id});
function svcModal(id){
 const s=svc(id)||{name:'',tag:'',price:5000,est:'1 hari',desc:'',feat:[]};
 openModal(`<button class="x" data-act="close" aria-label="Tutup">✕</button><h3>${id?'Edit':'Tambah'} layanan</h3><form id="sf" style="margin-top:16px"><div id="sm2"></div>
 ${[['name','Nama layanan'],['tag','Label (mis. Paket hemat)'],['est','Estimasi selesai'],['desc','Deskripsi singkat']].map(k=>`<div class="field"><label>${k[1]}</label><input class="inp" name="${k[0]}" value="${esc(s[k[0]])}" ${k[0]==='name'?'required':''}></div>`).join('')}
 <div class="field"><label>Harga per kg (Rp)</label><input class="inp" type="number" min="500" step="500" name="price" value="${s.price}" required></div>
 <div class="field"><label>Keunggulan (satu per baris)</label><textarea class="inp" name="feat" rows="3">${esc(s.feat.join('\n'))}</textarea></div>
 <div class="acts"><button type="button" class="btn ghost" data-act="close">Batal</button><button class="btn">Simpan</button></div></form>`);
 $('#sf').onsubmit=e=>{e.preventDefault();const f=e.target;if(!f.name.value.trim())return mErr('#sm2','Nama layanan wajib diisi.');
  closeModal();act('savesvc',{id:id||null,name:f.name.value,tag:f.tag.value,est:f.est.value,desc:f.desc.value,price:+f.price.value,feat:f.feat.value.split('\n')},'Layanan disimpan')}}

/* ---- mesin: monitoring, konfigurasi (PBI-01), rekap penggunaan (PBI-05) ---- */
const hrs=m=>(m/60).toFixed(1).replace('.',',')+' jam';
PAGES.owner.mesin=()=>{
 const all=db.machines,tc=all.reduce((a,m)=>a+m.cycles,0),tm=all.reduce((a,m)=>a+m.totalMin,0);
 return `<div class="card"><h3>Monitoring mesin</h3><div class="sub">Status unit mesin aktif secara langsung.</div>${machCards(all.filter(m=>m.active))}</div>
 <div class="card"><div class="between wrap"><div><h3>Konfigurasi unit mesin</h3><div class="sub">Data spesifikasi mesin cuci yang tercatat di sistem.</div></div><button class="btn" data-act="mnew">＋ Tambah Mesin</button></div>
 <div class="tbl">${all.length?`<table><tr><th>Nama</th><th>Tipe</th><th>Kapasitas</th><th>Status</th><th>Aksi</th></tr>${all.map(m=>{const s=mState(m);return `<tr style="${m.active?'':'opacity:.55'}"><td><b>${esc(m.name)}</b></td><td>${esc(m.type)}</td><td>${m.cap} kg</td><td><span class="badge ${{run:'b-proc',done:'b-rdy',mnt:'b-x',idle:'',off:''}[s]}">${{run:'Mencuci',done:'Selesai',mnt:'Perbaikan',idle:'Tersedia',off:'Nonaktif'}[s]}</span></td>
 <td><button class="btn sm out" data-act="medit" data-id="${m.id}">Edit</button> <button class="btn sm ghost" data-act="mtog" data-id="${m.id}" ${m.orderId?'disabled':''}>${m.active?'Nonaktifkan':'Aktifkan'}</button></td></tr>`}).join('')}</table>`:empty('Belum ada mesin','Tambahkan unit mesin pertama.')}</div></div>
 <div class="card"><h3>Riwayat & rekap penggunaan mesin</h3><div class="sub">Total ${tc} siklus • ${hrs(tm)} waktu pakai. Dasar analisis layanan.</div><div class="tbl">${all.length?`<table><tr><th>Mesin</th><th>Siklus selesai</th><th>Total waktu pakai</th><th>Rata-rata / siklus</th></tr>${all.map(m=>`<tr><td>${esc(m.name)}</td><td>${m.cycles}</td><td>${hrs(m.totalMin)}</td><td>${m.cycles?Math.round(m.totalMin/m.cycles)+' menit':'-'}</td></tr>`).join('')}</table>`:empty('Belum ada data')}</div></div>${logCard(15)}`};
ACT.mnew=()=>mModal();ACT.medit=id=>mModal(+id);ACT.mtog=id=>act('machine_toggle',{id:+id});
function mModal(id){
 const m=db.machines.find(m=>m.id===id)||{name:'Mesin 0'+(db.machines.length+1),type:'Front load',cap:15};
 openModal(`<button class="x" data-act="close" aria-label="Tutup">✕</button><h3>${id?'Edit':'Tambah'} mesin</h3><form id="mf" style="margin-top:16px"><div id="mm"></div>
 <div class="field"><label>Nama mesin</label><input class="inp" name="name" value="${esc(m.name)}" maxlength="40" required></div>
 <div class="field"><label>Tipe</label><input class="inp" name="type" list="mtypes" value="${esc(m.type)}" maxlength="40"><datalist id="mtypes"><option>Front load</option><option>Top load</option><option>Pengering</option></datalist></div>
 <div class="field"><label>Kapasitas (kg)</label><input class="inp" type="number" name="cap" min="1" max="50" value="${m.cap}" required></div>
 <div class="acts"><button type="button" class="btn ghost" data-act="close">Batal</button><button class="btn">Simpan</button></div></form>`);
 $('#mf').onsubmit=e=>{e.preventDefault();const f=e.target;closeModal();act('machine_save',{id:id||0,name:f.name.value,type:f.type.value,cap:+f.cap.value},'Konfigurasi mesin disimpan')}}

/* ---- kinerja petugas ---- */
PAGES.owner.kinerja=()=>{
 const rows=db.staff.map(p=>{const h=db.orders.filter(o=>o.handledBy===p.id),fin=h.filter(o=>['Siap Diambil','Telah Diambil'].includes(o.status)),rev=h.filter(o=>o.paid&&o.status!=='Dibatalkan').reduce((a,o)=>a+o.total,0);return {p,n:h.length,fin:fin.length,rev}}).sort((a,b)=>b.n-a.n);
 return `<div class="card"><h3>Kinerja petugas</h3><div class="sub">Dihitung dari pesanan yang diproses tiap petugas.</div><div class="tbl">${rows.length?`<table><tr><th>#</th><th>Petugas</th><th>Shift</th><th>Akun</th><th>Pesanan diproses</th><th>Selesai</th><th>Nilai ditangani</th></tr>${rows.map((r,i)=>`<tr><td>${i+1}</td><td><b>${esc(r.p.name)}</b><div class="mut small">${esc(r.p.email)}</div></td><td>${r.p.shift}</td><td><span class="badge ${r.p.active?'b-rdy':'b-x'}">${r.p.active?'Aktif':'Nonaktif'}</span></td><td>${r.n}</td><td>${r.fin}</td><td>${rp(r.rev)}</td></tr>`).join('')}</table>`:empty('Belum ada petugas','Tambahkan petugas di Manajemen Karyawan.')}</div></div>`};

/* ---- manajemen karyawan ---- */
PAGES.owner.karyawan=()=>`<div class="between wrap"><div><h2 style="font-size:24px">Manajemen karyawan</h2><p class="mut">Tambah, ubah, dan nonaktifkan akun Petugas.</p></div><button class="btn" data-act="snew">＋ Tambah Petugas</button></div>
 <div class="card"><div class="tbl">${db.staff.length?`<table><tr><th>Nama</th><th>Email</th><th>No. HP</th><th>Shift</th><th>Status</th><th>Aksi</th></tr>${db.staff.map(p=>`<tr style="${p.active?'':'opacity:.6'}"><td><b>${esc(p.name)}</b></td><td>${esc(p.email)}</td><td>${esc(p.phone||'-')}</td><td>${p.shift}</td><td><span class="badge ${p.active?'b-rdy':'b-x'}">${p.active?'Aktif':'Nonaktif'}</span></td>
 <td><button class="btn sm out" data-act="sedit" data-id="${p.id}">Ubah</button> <button class="btn sm ghost" data-act="stog" data-id="${p.id}">${p.active?'Nonaktifkan':'Aktifkan'}</button></td></tr>`).join('')}</table>`:empty('Belum ada petugas','Tambahkan akun petugas pertama.')}</div></div>
 <div class="info-bar">Petugas yang dinonaktifkan tidak bisa login dan sesinya langsung berakhir. Untuk mengatur ulang sandi petugas, pilih <b>Ubah</b> lalu isi kata sandi baru.</div>`;
ACT.snew=()=>sModal();ACT.sedit=id=>sModal(+id);
ACT.stog=id=>{const p=db.staff.find(p=>p.id===+id);if(!p.active||confirm('Nonaktifkan akun '+p.name+'? Petugas tidak bisa login lagi.'))act('staff_toggle',{id:+id},p.active?'Akun dinonaktifkan':'Akun diaktifkan')};
function sModal(id){
 const p=db.staff.find(p=>p.id===id)||{name:'',email:'',phone:'',shift:'pagi'};
 openModal(`<button class="x" data-act="close" aria-label="Tutup">✕</button><h3>${id?'Ubah':'Tambah'} petugas</h3><form id="stf" style="margin-top:16px"><div id="stm"></div>
 <div class="field"><label>Nama lengkap</label><input class="inp" name="name" value="${esc(p.name)}" maxlength="100" required></div>
 <div class="field"><label>Email</label><input class="inp" name="email" type="email" value="${esc(p.email)}" required></div>
 <div class="field"><label>No. HP</label><input class="inp" name="phone" value="${esc(p.phone||'')}" maxlength="30"></div>
 <div class="field"><label>Shift</label><select class="inp" name="shift">${Object.entries(SHIFT).map(([k,v])=>`<option value="${k}" ${p.shift===k?'selected':''}>${v}</option>`).join('')}</select></div>
 <div class="field"><label>${id?'Kata sandi baru (kosongkan jika tidak diubah)':'Kata sandi awal (min. 6 karakter)'}</label><input class="inp" name="pw" type="password" autocomplete="new-password" ${id?'':'required'}></div>
 <div class="acts"><button type="button" class="btn ghost" data-act="close">Batal</button><button class="btn">Simpan</button></div></form>`);
 $('#stf').onsubmit=e=>{e.preventDefault();const f=e.target;
  if(!/^\S+@\S+\.\S+$/.test(f.email.value.trim()))return mErr('#stm','Format email belum benar.');
  if((!id||f.pw.value)&&f.pw.value.length<6)return mErr('#stm','Kata sandi minimal 6 karakter.');
  closeModal();act('staff_save',{id:id||0,name:f.name.value,email:f.email.value,phone:f.phone.value,shift:f.shift.value,pw:f.pw.value},id?'Data petugas disimpan':'Petugas ditambahkan')}}
