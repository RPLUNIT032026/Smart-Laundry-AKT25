'use strict';
/* Pengaturan akun. Isi tiap peran berbeda: Pelanggan, Petugas, Owner */
const SET_TABS={
 pelanggan:[['profil','Profil'],['notifikasi','Notifikasi'],['preferensi','Preferensi'],['keamanan','Keamanan']],
 petugas:[['profil','Profil'],['tugas','Tugas & Shift'],['preferensi','Preferensi'],['keamanan','Keamanan']],
 owner:[['profil','Profil'],['usaha','Info Usaha'],['notifikasi','Notifikasi'],['preferensi','Preferensi'],['keamanan','Keamanan']]};
const ACCESS={
 pelanggan:['Membuat dan membatalkan pesanan sendiri','Membayar lewat QRIS dan melihat struk','Melacak status cucian','Mengubah profil dan kata sandi sendiri'],
 petugas:['Melihat dan memproses antrean pesanan','Mencatat pesanan pelanggan yang datang langsung','Menerima pembayaran tunai dan konfirmasi QRIS','Mengontrol status mesin (siaga / perbaikan)','Tidak dapat mengubah tarif atau akun karyawan'],
 owner:['Akses penuh dashboard dan laporan','Mengelola layanan, tarif, dan konfigurasi mesin','Menambah, mengubah, dan menonaktifkan akun Petugas','Mengatur info usaha']};
const sw=(k,label,desc,on)=>`<label class="swrow"><div><b>${label}</b><small>${desc}</small></div><input type="checkbox" class="sw" data-pref="${k}" ${on?'checked':''}></label>`;
function pSettings(u,sub){
 const tabs=SET_TABS[u.role],tab=tabs.some(t=>t[0]===sub)?sub:'profil',p=pref();
 const body={
 profil:()=>`<div class="card"><h3>Profil</h3><div class="sub">Data akun ${ROLE[u.role].toLowerCase()} kamu.</div>
  <div class="photo-row">${avatar(u,'xl')}<div><div class="acts" style="flex-wrap:wrap"><label class="btn out sm" for="pfile">📷 ${u.photo?'Ganti foto':'Unggah foto'}</label>${u.photo?'<button class="btn ghost sm" data-act="rmphoto">Hapus foto</button>':''}</div><input id="pfile" type="file" accept="image/jpeg,image/png,image/webp" hidden><small class="mut">JPG, PNG, atau WebP. Foto otomatis dipotong persegi.</small></div></div>
  <form id="pf"><div id="pm"></div><div class="grid2"><div class="field"><label>Nama lengkap</label><input class="inp" name="name" value="${esc(u.name)}" maxlength="100" required></div>
  <div class="field"><label>Email</label><input class="inp" name="email" type="email" value="${esc(u.email)}" required></div>
  <div class="field"><label>No. HP / WhatsApp</label><input class="inp" name="phone" inputmode="tel" value="${esc(u.phone||'')}" maxlength="30"></div>
  <div class="field"><label>Peran</label><input class="inp" value="${ROLE[u.role]}${u.role==='petugas'?' · '+SHIFT[u.shift].split(' · ')[0]:''}" disabled></div></div>
  ${u.role==='pelanggan'?`<div class="field"><label>Alamat (untuk antar-jemput)</label><textarea class="inp" name="address" rows="2" maxlength="255">${esc(u.address||'')}</textarea></div>`:''}
  <div class="field"><label>${u.role==='pelanggan'?'Catatan profil (mis. alergi deterjen)':u.role==='petugas'?'Catatan tugas':'Tentang saya'}</label><input class="inp" name="note" value="${esc(u.note||'')}" maxlength="255"></div>
  <button class="btn">Simpan profil</button></form></div>`,
 notifikasi:()=>`<div class="card"><h3>Notifikasi</h3><div class="sub">${u.role==='owner'?'Atur ringkasan dan peringatan operasional.':'Pilih cara kami mengabari status cucianmu.'}</div>
  ${sw('notif_wa',u.role==='owner'?'Peringatan mesin via WhatsApp':'Notifikasi WhatsApp',u.role==='owner'?'Kabari saat mesin masuk perbaikan atau selesai.':'Kabari saat status pesanan berubah.',u.notif_wa)}
  ${sw('notif_email',u.role==='owner'?'Ringkasan harian via email':'Notifikasi email',u.role==='owner'?'Ringkasan pendapatan dan pesanan tiap hari.':'Kirim struk dan pembaruan ke email.',u.notif_email)}
  <p class="mut small" style="margin-top:12px">Preferensi tersimpan di akunmu. Pengiriman WhatsApp/email aktif setelah layanan pengiriman dihubungkan.</p></div>`,
 tugas:()=>`<div class="card"><h3>Tugas & shift</h3><div class="sub">Shift diatur oleh Owner.</div><div class="info-bar" style="margin:0 0 14px"><b>${SHIFT[u.shift]}</b></div>
  ${sw('notif_queue','Notifikasi pesanan baru','Tampilkan pemberitahuan saat ada pesanan masuk ke antrean.',u.notif_queue)}</div>
  <div class="card"><h3>Hak akses petugas</h3><ul class="access">${ACCESS.petugas.map(a=>`<li>${a}</li>`).join('')}</ul></div>`,
 usaha:()=>`<div class="card"><h3>Info usaha</h3><div class="sub">Tampil di struk dan halaman Bantuan.</div><form id="bf"><div id="bm"></div><div class="grid2">
  <div class="field"><label>Nama usaha</label><input class="inp" name="biz_name" value="${esc(db.settings.biz_name||'')}" maxlength="80"></div>
  <div class="field"><label>WhatsApp usaha</label><input class="inp" name="biz_wa" inputmode="tel" value="${esc(db.settings.biz_wa||'')}" maxlength="30"></div>
  <div class="field"><label>Jam operasional</label><input class="inp" name="biz_hours" value="${esc(db.settings.biz_hours||'')}" maxlength="60"></div></div>
  <div class="field"><label>Alamat</label><textarea class="inp" name="biz_addr" rows="2" maxlength="200">${esc(db.settings.biz_addr||'')}</textarea></div><button class="btn">Simpan info usaha</button></form></div>
  <div class="card"><h3>Pintasan pengelolaan</h3><div class="quick"><a class="btn out" href="#/app/karyawan">☺ Manajemen Karyawan</a><a class="btn out" href="#/app/layanan">◈ Kelola Layanan</a><a class="btn out" href="#/app/mesin">◎ Konfigurasi Mesin</a><a class="btn out" href="#/app/laporan">☰ Laporan</a></div></div>
  <div class="card"><h3>Data aplikasi</h3><div class="sub">Data tersimpan di browser perangkat ini. Buat cadangan secara berkala atau pindahkan ke perangkat lain.</div>
  <div class="quick"><button class="btn out" data-act="backup">⭳ Unduh cadangan</button><label class="btn out" for="impfile">⭱ Pulihkan dari cadangan</label><input id="impfile" type="file" accept=".json,application/json" hidden><button class="btn ghost" style="color:var(--red-d)" data-act="resetall">Reset semua data</button></div></div>`,
 preferensi:()=>`<div class="card"><h3>Preferensi</h3><div class="sub">Tampilan dan perilaku aplikasi.</div>
  ${sw('dark','Mode gelap','Disimpan di perangkat ini.',p.dark)}${sw('auto_refresh','Segarkan data otomatis','Perbarui antrean dan status tiap 15 detik.',u.auto_refresh)}
  ${u.role==='pelanggan'?`<div class="swrow"><div><b>Metode pembayaran default</b><small>Terpilih otomatis saat membuat pesanan.</small></div><select class="inp" style="width:auto" data-pref="default_pay"><option value="qris" ${u.default_pay!=='cod'?'selected':''}>QRIS</option><option value="cod" ${u.default_pay==='cod'?'selected':''}>Bayar di tempat</option></select></div>`:''}</div>`,
 keamanan:()=>`<div class="card"><h3>Ubah kata sandi</h3><div class="sub">Gunakan kata sandi yang sulit ditebak.</div><form id="wf" style="max-width:420px"><div id="wm"></div>
  ${pwField('o','Kata sandi lama','','current-password')}${pwField('n','Kata sandi baru (min. 6 karakter)','','new-password')}${pwField('n2','Ulangi kata sandi baru','','new-password')}<button class="btn">Simpan kata sandi</button></form></div>
  <div class="card"><h3>Hak akses ${ROLE[u.role].toLowerCase()}</h3><ul class="access">${ACCESS[u.role].map(a=>`<li>${a}</li>`).join('')}</ul><div style="margin-top:14px"><button class="btn ghost" data-act="logout">Keluar dari akun</button></div></div>`}[tab]();
 return `<div class="set-wrap"><nav class="set-tabs" aria-label="Menu pengaturan">${tabs.map(t=>`<a class="${t[0]===tab?'on':''}" href="#/app/pengaturan/${t[0]}">${t[1]}</a>`).join('')}</nav><div class="set-body">${body}</div></div>`}
PAGES.pelanggan.pengaturan=PAGES.petugas.pengaturan=PAGES.owner.pengaturan=pSettings;

/* ---- penyimpanan pengaturan ---- */
document.addEventListener('submit',async e=>{
 const id=e.target.id;if(!['pf','bf','wf'].includes(id))return;e.preventDefault();const f=e.target,d=Object.fromEntries(new FormData(f));
 if(id==='pf'){if(!d.name.trim())return mErr('#pm','Nama wajib diisi.');if(!/^\S+@\S+\.\S+$/.test(d.email.trim()))return mErr('#pm','Format email belum benar.');
  const r=await api('profile',{...d,email:d.email.trim().toLowerCase()});if(r.error)return mErr('#pm',r.error);await sync();toast('Profil disimpan');route()}
 if(id==='bf'){const r=await api('bizsave',d);if(r.error)return mErr('#bm',r.error);await sync();toast('Info usaha disimpan');route()}
 if(id==='wf'){if(d.n.length<6)return mErr('#wm','Kata sandi baru minimal 6 karakter.');if(d.n!==d.n2)return mErr('#wm','Ulangi kata sandi tidak sama.');
  const r=await api('changepw',{old:d.o,pw:d.n});if(r.error)return mErr('#wm',r.error);f.reset();$('#wm').innerHTML='<div class="ok">Kata sandi berhasil diperbarui.</div>'}
});
document.addEventListener('change',async e=>{
 const t=e.target,k=t.dataset?.pref;
 if(k){if(k==='dark')return setPref({dark:t.checked});
  const v=k==='default_pay'?t.value:t.checked?1:0,r=await api('profile',{[k]:v});if(r.error){toast(r.error);return}await sync().catch(()=>{});toast('Pengaturan disimpan');return}
 if(t.id==='pfile'&&t.files[0])uploadPhoto(t.files[0]);
});
function uploadPhoto(file){
 if(!/^image\//.test(file.type))return toast('Pilih file gambar.');
 const img=new Image,url=URL.createObjectURL(file);
 img.onload=async()=>{const S=256,c=document.createElement('canvas');c.width=c.height=S;const s=Math.min(img.width,img.height),x=(img.width-s)/2,y=(img.height-s)/2;
  c.getContext('2d').drawImage(img,x,y,s,s,0,0,S,S);URL.revokeObjectURL(url);
  const r=await api('photo',{data:c.toDataURL('image/jpeg',.85)});if(r.error)return toast(r.error);await sync();toast('Foto profil diperbarui');route()};
 img.onerror=()=>toast('Gambar tidak bisa dibaca.');img.src=url}
ACT.rmphoto=async()=>{const r=await api('photo',{data:''});if(r.error)return toast(r.error);await sync();toast('Foto dihapus');route()};

ACT.backup=async()=>{const r=await api('export');if(r.error)return toast(r.error);const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([r.json],{type:'application/json'}));a.download='cadangan-washwash-'+new Date().toISOString().slice(0,10)+'.json';a.click();toast('Cadangan diunduh')};
ACT.resetall=async()=>{if(!confirm('Hapus SEMUA data (pesanan, pelanggan, pengaturan) dan kembali ke awal? Tindakan ini tidak bisa dibatalkan.'))return;const r=await api('resetall');if(r.error)return toast(r.error);await sync();toast('Data dikembalikan ke awal');route()};
document.addEventListener('change',e=>{if(e.target.id!=='impfile'||!e.target.files[0])return;const f=e.target.files[0],rd=new FileReader();
 rd.onload=async()=>{if(!confirm('Pulihkan dari file ini? Data saat ini akan diganti.'))return;const r=await api('import',{data:rd.result});if(r.error)return toast(r.error);try{await sync()}catch(x){}toast('Data dipulihkan');route()};rd.readAsText(f)});
