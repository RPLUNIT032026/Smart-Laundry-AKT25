'use strict';
/* Fitur Customer: dashboard, lacak status, buat pesanan, pembayaran QRIS, struk */
const ACTIVE=['Menunggu Antrean','Diproses Mesin','Siap Diambil'];
let trackIdx=0;
const myOrders=u=>db.orders.filter(o=>o.uid===u.id).sort((a,b)=>b.n-a.n);
function roomStat(){const r=db.room,n=r.waiting+r.running+r.ready,lv=n<=2?['Sepi','b-rdy',18]:n<=5?['Sedang','b-wait',60]:['Ramai','b-x',95];
 return `<div class="card stat" style="flex-wrap:wrap"><div class="ic" style="background:var(--grn)">👥</div><div><small>Ruang tunggu</small><b style="font-size:20px">${lv[0]}</b><span>${n} pesanan di antrean/proses</span></div><div class="bar" style="width:100%"><i style="width:${lv[2]}%"></i></div></div>`}
function track(o){
 const m=db.machines.find(m=>m.orderId===o.n),cust=me().role==='pelanggan',pending=o.pay==='qris'&&!o.paid&&o.status!=='Dibatalkan';
 return `<div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;gap:10px"><div><b>#${oid(o.n)}</b><div class="mut small">${esc(o.sname)} ${o.kg}kg • ${rp(o.total)} • ${o.paid?'Lunas':'Belum dibayar'}</div></div>${badge(o.status)}</div>
 ${stepsHtml(o)}
 ${pending&&cust?`<div class="note-warn">Menunggu pembayaran QRIS agar cucianmu bisa diproses. <button class="btn sm" data-act="pay" data-id="${o.n}">Bayar sekarang</button></div>`:''}
 <div class="trk-foot"><span>${m?m.name+' • Perkiraan selesai '+fmtT(m.start+m.dur*60000):'Mesin akan ditentukan petugas'}</span>
 ${o.status==='Menunggu Antrean'&&cust?`<button class="btn sm ghost" data-act="cancel" data-id="${o.n}">Batalkan Pesanan</button>`:''}</div>`}
PAGES.pelanggan.dashboard=u=>{
 const my=myOrders(u),act=my.filter(o=>ACTIVE.includes(o.status)),wait=my.filter(o=>o.status==='Menunggu Antrean').length,done=my.filter(o=>o.status==='Telah Diambil').length;
 trackIdx=Math.min(trackIdx,Math.max(0,act.length-1));const o=act[trackIdx];
 return `<div class="hero"><div><h2>Buat Harimu Lebih Santai</h2><p>Buat pesanan, pantau prosesnya, dan tunggu cucian kembali bersih.</p></div><button class="btn" data-act="new">＋ Buat Pesanan Baru</button></div>
 <div class="stats">${statCard('Cucian Aktif',act.length,'pesanan berjalan','🧺')}${statCard('Menunggu Antrean',wait,'pesanan menunggu','⏱')}${statCard('Selesai',done,'pesanan telah selesai','✓')}${roomStat()}</div>
 <div class="card"><div class="between"><h3>Pelacakan Pesanan Aktif</h3>${act.length>1?`<span class="mut small"><button class="btn sm ghost" data-act="tprev">‹</button> ${trackIdx+1} dari ${act.length} <button class="btn sm ghost" data-act="tnext">›</button></span>`:act.length?`<span class="mut small">1 dari 1 pesanan</span>`:''}</div>
 ${o?track(o):empty('Belum ada cucian aktif','Tekan Buat Pesanan Baru untuk memulai.')}</div>
 <div class="card"><div class="between"><h3>Riwayat Pesanan</h3>${my.length>6?'<a data-act="hist">Lihat semua riwayat →</a>':''}</div><div class="tbl">${my.length?`<table><tr><th>No. Order</th><th>Tanggal</th><th>Layanan & Berat</th><th>Total Harga</th><th>Status</th><th>Aksi</th></tr>
 ${my.slice(0,6).map(histRow).join('')}</table>`:empty('Belum ada pesanan','Pesanan yang kamu buat akan muncul di sini.')}</div></div>`};
const histRow=o=>`<tr><td><a class="id" data-act="detail" data-id="${o.n}">#${oid(o.n)}</a></td><td>${fmtD(o.t)}</td><td>${esc(o.sname)} • ${o.kg} kg</td><td>${rp(o.total)}</td><td>${badge(o.status)} ${payBadge(o)}</td>
 <td><button class="btn sm out" data-act="detail" data-id="${o.n}">Detail ›</button> ${o.pay==='qris'&&!o.paid&&o.status!=='Dibatalkan'?`<button class="btn sm" data-act="pay" data-id="${o.n}">Bayar</button>`:''}</td></tr>`;
PAGES.pelanggan.pesanan=u=>{
 const my=myOrders(u),act=my.filter(o=>ACTIVE.includes(o.status)),old=my.filter(o=>!ACTIVE.includes(o.status));
 if(!my.length)return `<div class="card empty"><b>Belum ada pesanan untuk dilacak</b>Buat pesanan pertamamu, lalu pantau tiap tahapnya di sini.<br><br><button class="btn" data-act="new">＋ Buat Pesanan Baru</button></div>`;
 return `<div class="between wrap"><div><h2 style="font-size:22px">Pantau cucianmu</h2><p class="mut">${act.length?act.length+' pesanan sedang berjalan.':'Tidak ada cucian yang sedang berjalan.'}</p></div><button class="btn" data-act="new">＋ Buat Pesanan Baru</button></div>
 ${act.length?act.map(o=>`<div class="card">${track(o)}<div style="margin-top:12px"><button class="btn sm out" data-act="detail" data-id="${o.n}">Lihat detail ›</button></div></div>`).join(''):`<div class="card">${empty('Semua cucian sudah selesai','Pesanan baru akan muncul di sini.')}</div>`}
 ${old.length?`<div class="card"><h3>Pesanan selesai & dibatalkan</h3><div class="sub">Riwayat pelacakan sebelumnya. Buka detail untuk melihat struk.</div><div class="tbl"><table><tr><th>No. Order</th><th>Tanggal</th><th>Layanan & Berat</th><th>Total Harga</th><th>Status</th><th>Aksi</th></tr>${old.map(histRow).join('')}</table></div></div>`:''}`};
ACT.hist=()=>go('/app/pesanan');
ACT.tprev=()=>{trackIdx=Math.max(0,trackIdx-1);route()};
ACT.tnext=()=>{trackIdx++;route()};
ACT.cancel=id=>{if(confirm('Batalkan pesanan ini?'))act('cancel',{n:+id},'Pesanan dibatalkan')};
ACT.new=()=>{const u=me();
 const sv=db.services.filter(s=>s.on),free=freeMachines();
 if(!sv.length)return openModal(`<h3>Belum ada layanan</h3><p class="mut" style="margin:12px 0">Owner belum mengaktifkan layanan. Coba lagi nanti.</p><button class="btn block" data-act="close">Tutup</button>`);
 openModal(`<button class="x" data-act="close" aria-label="Tutup">✕</button><h3>Buat Pesanan Baru</h3><p class="mut small" style="margin:4px 0 16px">Smart Laundry Digital Twin System</p><form id="of">
 <div class="field"><label><b>Pilih Jenis Layanan Mesin</b></label>${sv.map((s,i)=>`<label class="opt"><span><input type="radio" name="sid" value="${s.id}" ${i?'':'checked'}>${esc(s.name)}</span><span>${rp(s.price)}/kg</span></label>`).join('')}</div>
 <div class="field"><label><b>Perkiraan Berat Cucian (Kg)</b></label><div class="qty"><button type="button" data-act="q" data-id="-1">−</button><input name="kg" type="number" min="1" max="15" value="3"><button type="button" data-act="q" data-id="1">＋</button></div></div>
 <div class="field"><label><b>Pilih Unit Mesin Tersedia</b></label><select class="inp" name="mid"><option value="">Biarkan petugas memilih</option>${free.map(m=>`<option value="${m.id}">${esc(m.name)} - Kapasitas ${m.cap} kg (Siaga / Kosong)</option>`).join('')}</select></div>
 <div class="field"><label><b>Catatan Tambahan</b> (opsional)</label><textarea class="inp" name="note" rows="2" maxlength="200" placeholder="Contoh: Pisahkan baju putih"></textarea></div>
 <div class="field"><label><b>Metode Pembayaran</b></label><div class="roles two"><label><input type="radio" name="pay" value="qris" ${u.default_pay==='cod'?'':'checked'}><span>Pembayaran Digital / QRIS</span></label><label><input type="radio" name="pay" value="cod" ${u.default_pay==='cod'?'checked':''}><span>Bayar di Tempat</span></label></div></div>
 <div class="tot"><div><small>Total Estimasi Biaya</small><div class="small" id="est"></div></div><b id="tt"></b></div>
 <div class="acts"><button type="button" class="btn ghost" data-act="close">Batal</button><button class="btn">Kirim Pesanan</button></div></form>`);
 const f=$('#of'),upd=()=>{const s=svc(f.sid.value),kg=Math.max(1,Math.min(15,+f.kg.value||1));$('#tt').textContent=rp(s.price*kg);$('#est').textContent='Estimasi selesai: '+s.est};
 f.oninput=upd;upd();
 f.onsubmit=async e=>{e.preventDefault();const kg=Math.max(1,Math.min(15,+f.kg.value||1)),pay=f.pay.value;
  closeModal();const r=await act('order',{sid:f.sid.value,kg,pay,mid:f.mid.value||null,note:f.note.value.trim()},'Pesanan terkirim');
  if(r.n&&pay==='qris')payModal(r.n)};
};
ACT.q=id=>{const i=$('#of input[name=kg]');i.value=Math.max(1,Math.min(15,(+i.value||1)+ +id));$('#of').dispatchEvent(new Event('input'))};

/* ---- pembayaran QRIS ---- */
function payModal(n){
 const o=db.orders.find(o=>o.n===+n);if(!o)return;if(o.paid||o.status==='Dibatalkan')return detailModal(n);
 const left=o.qrisExp-Date.now(),isC=me().role==='pelanggan';
 openModal(`<button class="x" data-act="close" aria-label="Tutup">✕</button><h3>Pembayaran QRIS</h3><p class="mut small" style="margin:4px 0 12px">#${oid(o.n)} • ${esc(o.sname)} ${o.kg} kg</p>
 <div class="qrbox">${left<=0?'<div class="qr-exp">QRIS kedaluwarsa</div>':`<img src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data=${encodeURIComponent('WASHWASH|'+o.ref+'|'+o.total)}" alt="Kode QRIS" onerror="this.outerHTML='<div class=qr-exp>QR tidak dapat dimuat. Periksa koneksi internet.</div>'">`}</div>
 <div class="tot"><div><small>Total pembayaran</small><div class="small">Ref: ${esc(o.ref||'-')}</div></div><b>${rp(o.total)}</b></div>
 <p class="center">${left<=0?'Waktu pembayaran habis.':`Selesaikan dalam <b data-exp="${o.qrisExp}" data-n="${o.n}">${clock(left)}</b>`}</p>
 <div class="acts">${left<=0?`<button class="btn" data-act="reissue" data-id="${o.n}">Terbitkan ulang QRIS</button>`:`<button class="btn" data-act="payok" data-id="${o.n}">${isC?'Saya sudah membayar':'Konfirmasi sudah dibayar'}</button>`}<button class="btn ghost" data-act="close">${isC?'Bayar nanti':'Tutup'}</button></div>
 <p class="mut small center" style="margin-top:10px">Simulasi: tombol konfirmasi menandai pesanan lunas.</p>`)}
TICK.push(()=>{const el=$('[data-exp]');if(el&&+el.dataset.exp-Date.now()<=0)payModal(el.dataset.n)});
ACT.pay=id=>payModal(id);
ACT.payok=async id=>{closeModal();const r=await act('payconfirm',{n:+id},'Pembayaran berhasil');if(!r.error)detailModal(id)};
ACT.reissue=async id=>{await act('qrisreissue',{n:+id},'QRIS baru diterbitkan');payModal(id)};

/* ---- detail & struk ---- */
function detailModal(n){
 const o=db.orders.find(o=>o.n===+n);if(!o)return;const b=db.settings||{},u=me();
 const rows=[['Pelanggan',esc(o.cust)],['Layanan',esc(o.sname)],['Berat',o.kg+' kg'],['Harga / kg',rp(o.total/o.kg)],['Total',`<b>${rp(o.total)}</b>`],['Metode',o.pay==='qris'?'QRIS':'Bayar di tempat'],
  ['Pembayaran',o.paid?'Lunas • '+fmtD(o.paidAt)+' '+fmtT(o.paidAt):'Belum dibayar']];
 if(o.pay==='qris'&&o.ref)rows.push(['Ref. QRIS',esc(o.ref)]);
 if(o.paid&&o.received!=null&&o.pay==='cod')rows.push(['Uang diterima',rp(o.received)],['Kembalian',rp(o.changeAmt)]);
 rows.push(['Dibuat',fmtD(o.t)+' '+fmtT(o.t)]);if(o.hname)rows.push(['Petugas',esc(o.hname)]);if(o.note)rows.push(['Catatan',esc(o.note)]);
 openModal(`<button class="x" data-act="close" aria-label="Tutup">✕</button><div id="struk"><div class="st-h"><b>${esc(b.biz_name||'Wash Wash Laundry')}</b><small>${esc(b.biz_addr||'')}</small></div>
 <h3>#${oid(o.n)}</h3><div style="margin:8px 0 12px">${badge(o.status)} ${payBadge(o)}</div><table class="kv">${rows.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td></tr>`).join('')}</table>
 ${o.status==='Dibatalkan'?'':stepsHtml(o)}${o.paid?'<p class="center mut small st-f">Terima kasih telah mencuci di Wash Wash Laundry</p>':''}</div>
 <div class="acts">${o.paid?'<button class="btn out" data-act="print">🖨 Cetak Struk</button>':''}${!o.paid&&o.pay==='qris'&&o.status!=='Dibatalkan'?`<button class="btn" data-act="pay" data-id="${o.n}">${u.role==='pelanggan'?'Bayar QRIS':'Tampilkan QRIS'}</button>`:''}<button class="btn ghost" data-act="close">Tutup</button></div>`,'struk-mod')}
ACT.detail=id=>detailModal(id);
ACT.print=()=>window.print();
