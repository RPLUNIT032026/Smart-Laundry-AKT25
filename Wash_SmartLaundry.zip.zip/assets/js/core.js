'use strict';
/* Wash Wash Laundry - inti aplikasi: state, API, router, kerangka halaman, modal */
const FLOW=['Dibuat','Menunggu Antrean','Diproses Mesin','Siap Diambil','Telah Diambil'];
const ROLE={pelanggan:'Pelanggan',petugas:'Petugas',owner:'Owner'};
const SHIFT={pagi:'Shift pagi · 08.00–16.00',siang:'Shift siang · 12.00–20.00',malam:'Shift malam · 16.00–23.00'};
let db={user:null,orders:[],services:[],machines:[],log:[],staff:[],settings:{},room:{waiting:0,running:0,ready:0}};
const PAGES={pelanggan:{},petugas:{},owner:{}},ACT={},TICK=[];
const NAV={
 pelanggan:[['dashboard','Dashboard','▦'],['new','Buat Pesanan','＋',1],['pesanan','Pantau / Lacak Status','☰']],
 petugas:[['dashboard','Dashboard','▦'],['antrean','Lihat Antrean','☰'],['mesin','Monitoring Mesin IoT','◎'],['status','Update Status','✎']],
 owner:[['dashboard','Dashboard','▦'],['laporan','Lihat Laporan','☰'],['layanan','Kelola Layanan','◈'],['mesin','Monitoring & Riwayat Mesin','◎'],['kinerja','Pantau Kinerja','▤'],['karyawan','Manajemen Karyawan','☺']]};
const TITLE={antrean:'Antrean pesanan',mesin:'Monitoring mesin',status:'Update status',laporan:'Laporan transaksi',layanan:'Manajemen layanan',kinerja:'Pantau kinerja',karyawan:'Manajemen karyawan',pesanan:'Pantau / Lacak Status',pengaturan:'Pengaturan',owner_mesin:'Monitoring & Riwayat Mesin'};

/* ---- helper ---- */
const $=(s,e=document)=>e.querySelector(s),$$=(s,e=document)=>[...e.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const rp=n=>'Rp'+Number(n||0).toLocaleString('id-ID');
const fmtD=t=>new Date(t).toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'});
const fmtT=t=>new Date(t).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}).replace('.',':');
const today=()=>new Date().toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
const greet=()=>{const h=new Date().getHours();return h<11?'Selamat pagi':h<15?'Selamat siang':h<18?'Selamat sore':'Selamat malam'};
const me=()=>db.user,svc=id=>db.services.find(s=>s.id===id),oid=n=>'WW-'+String(n).padStart(4,'0');
const go=h=>{location.hash=h};
const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toast.h);toast.h=setTimeout(()=>t.classList.remove('on'),2800)};
const clock=ms=>{const s=Math.ceil(ms/1000);return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')};
const mRem=m=>m.orderId?Math.max(0,m.start+m.dur*60000-Date.now()):0;
const badge=s=>`<span class="badge ${{'Menunggu Antrean':'b-wait','Diproses Mesin':'b-proc','Siap Diambil':'b-rdy','Dibatalkan':'b-x'}[s]||''}">${esc(s)}</span>`;
const payBadge=o=>o.status==='Dibatalkan'?'':o.paid?'<span class="badge b-rdy">Lunas</span>':'<span class="badge b-wait">Belum bayar</span>';
const empty=(t,d)=>`<div class="empty"><b>${t}</b>${d||''}</div>`;
const freeMachines=()=>db.machines.filter(m=>m.active&&!m.orderId&&m.status==='idle');
const mState=m=>!m.active?'off':m.orderId?(mRem(m)?'run':'done'):m.status==='maintenance'?'mnt':'idle';
const initial=u=>esc((u.name||'?').trim()[0]?.toUpperCase()||'?');
const avatar=(u,c='')=>`<span class="av ${c}">${u.photo?`<img src="${esc(u.photo)}" alt="">`:initial(u)}</span>`;
const pref=()=>{try{return JSON.parse(localStorage.getItem('ww_pref'))||{}}catch(e){return{}}};
const setPref=p=>{try{localStorage.setItem('ww_pref',JSON.stringify({...pref(),...p}))}catch(e){}applyPref()};
const applyPref=()=>{document.documentElement.dataset.theme=pref().dark?'dark':'light'};applyPref();

/* ---- API & state ---- */
const api=(a,body)=>Promise.resolve().then(()=>{try{return LocalAPI(a,body)}catch(e){if(e&&e.error)return{error:e.error};console.error(e);return{error:'Terjadi kesalahan: '+(e&&e.message||e)}}});
let snap='';
async function sync(){const r=LocalAPI('state'),s=JSON.stringify(r),ch=s!==snap;snap=s;db=r;return ch}
function fatal(e){
 const msg=(e&&e.message)||String(e||'Tidak diketahui');
 const tip=location.protocol==='file:'
  ?'Kamu membuka file langsung dari folder. Kalau error terus, coba: (1) pastikan folder assets ada di samping index.html, (2) buka pakai Chrome/Edge, (3) atau klik kanan index.html → Open with → Chrome.'
  :'Pastikan localStorage tidak diblokir, lalu muat ulang (Ctrl+F5).';
 $('#app').innerHTML=`<div class="doc"><h1>Terjadi kesalahan</h1><p>${esc(msg)}</p><p>${tip}</p><p><button class="btn" onclick="location.hash='/masuk';location.reload()">Muat ulang</button></p></div>`
}
const act=async(a,body,msg)=>{const r=await api(a,body);if(r.error)toast(r.error);else if(msg)toast(msg);try{await sync()}catch(e){fatal(e);return r}route();return r};

/* ---- router ---- */
addEventListener('hashchange',()=>{closeModal();route()});
function route(){
 const [a,b,c]=location.hash.replace(/^#\/?/,'').split('/'),u=me();
 if(['kebijakan','syarat','bantuan'].includes(a))return docPage(a);
 if(a==='app'){if(!u)return go('/masuk');return shell(u,b||'dashboard',c)}
 if(u)return go('/app/dashboard');
 authPage(a==='daftar'?'daftar':a==='lupa'?'lupa':'masuk');
}

/* ---- kerangka dashboard ---- */
function shell(u,page,sub){
 const staff=u.role!=='pelanggan',pg=PAGES[u.role];if(!pg[page])page='dashboard';
 const title=page==='dashboard'?(staff?'Ringkasan operasional':'Dashboard Pelanggan'):(TITLE[u.role+'_'+page]||TITLE[page]||'Dashboard');
 const sub2=u.role==='petugas'?'Petugas · '+SHIFT[u.shift].split(' · ')[0]:u.role==='owner'?'Owner · Administrator':'Pelanggan';
 $('#app').innerHTML=`<div class="shell" id="shell"><div class="scrim" data-act="menu"></div>
 <aside class="side"><div class="logo"><img src="assets/img/logo-icon.png" alt="Wash Wash Laundry"><div><b>WASH WASH</b><small>LAUNDRY</small></div></div>
 ${staff?`<div class="grp">SMART LAUNDRY SYSTEM</div><div class="grp">AREA ${u.role==='owner'?'OWNER':'PETUGAS'}</div>`:''}
 ${NAV[u.role].map(n=>`<button class="nav ${n[0]===page?'on':''}" ${n[3]?`data-act="${n[0]}"`:`data-nav="${n[0]}"`}><span>${n[2]}</span>${n[1]}</button>`).join('')}
 <div class="sp"></div>
 ${staff?`<div class="help"><b style="color:var(--grn-d)">● Sistem terhubung</b>MQTT broker online<br>Sinkronisasi otomatis aktif</div>`:`<div class="help"><b>Butuh bantuan?</b>Kami siap membantu pesanan laundry kamu.<br><a href="#/bantuan">Hubungi kami ↗</a></div>`}
 <button class="nav" style="color:var(--red-d)" data-act="logout"><span>⎋</span>Logout</button></aside>
 <div class="main"><header class="top"><div class="l"><button class="burger" data-act="menu" aria-label="Menu">☰</button><div>
 ${staff?`<small>Workspace / ${ROLE[u.role]}</small><h2>${title}</h2>`:`<h2>${title}</h2><small>${today()}</small>`}</div></div>
 <div class="l">${staff?'<span class="chip">● Digital Twin • Terhubung</span>':''}<button class="bell" data-act="bell" title="Notifikasi" aria-label="Notifikasi">🔔</button>
 <div class="user-wrap"><button class="user" data-act="umenu" aria-haspopup="true">${avatar(u)}<div><b>${u.role==='pelanggan'?'Halo, '+esc(u.name.split(' ')[0]):esc(u.name)}</b><small style="color:var(--mut)">${sub2}</small></div><span>▾</span></button>
 <div class="umenu" id="umenu"><div class="hd"><b>${esc(u.name)}</b><small>${esc(u.email)}</small></div><a href="#/app/pengaturan/profil">Edit Profil</a><a href="#/app/pengaturan">Pengaturan</a><hr><a href="#/bantuan">Bantuan</a><a href="#/kebijakan">Kebijakan Privasi</a><a href="#/syarat">Syarat &amp; Ketentuan</a><hr><button data-act="logout" style="color:var(--red-d)">Logout</button></div></div></div></header>
 <main class="pg" id="pg"></main></div></div>`;
 $('#pg').innerHTML=pg[page](u,sub);
}

/* ---- komponen bersama ---- */
function machCards(list){
 list=list||db.machines.filter(m=>m.active);
 if(!list.length)return empty('Belum ada mesin','Owner dapat menambahkan mesin di menu Monitoring & Riwayat Mesin.');
 return `<div class="mgrid">${list.map(m=>{const o=db.orders.find(o=>o.n===m.orderId),r=mRem(m),s=mState(m);
 const lab={run:'Mencuci',done:'Selesai',mnt:'Perbaikan',idle:'Tersedia',off:'Nonaktif'}[s],cls={run:'b-proc',done:'b-rdy',mnt:'b-x',idle:'',off:''}[s];
 return `<div class="mach"><div class="t">${esc(m.name)}<span class="badge ${cls}">${lab}</span></div><small>${o?'Sisa waktu':s==='mnt'?'Sedang diperbaiki':'Siap beroperasi'} · ${m.cap} kg</small>
 <div class="tm" ${o?`data-m="${m.id}"`:''}>${o?clock(r):'00:00'}</div><small>${o?'#'+oid(o.n)+' • '+esc(o.cust)+' • '+o.kg+' kg':'Siap digunakan'}</small>
 ${o?`<div class="bar"><i data-b="${m.id}" style="width:${100-r/(m.dur*600)}%"></i></div>`:''}</div>`}).join('')}</div>`}
function logCard(n=10){return `<div class="card"><h3>Log MachineHistory</h3><div class="sub">Aktivitas mesin & pesanan.</div>${db.log.length?`<ul class="log">${db.log.slice(0,n).map(l=>`<li>${esc(l.x)}<small>${fmtD(l.t)} ${fmtT(l.t)}</small></li>`).join('')}</ul>`:empty('Belum ada aktivitas')}</div>`}
function stepsHtml(o){const i=FLOW.indexOf(o.status);return `<div class="steps">${FLOW.map((s,k)=>`<div class="${k<i?'d':k===i?'c':''}"><i>${k<i?'✓':k+1}</i>${s}</div>`).join('')}</div>`}
function statCard(label,val,sub,ic){return `<div class="card stat ${me()&&me().role!=='pelanggan'?'stk':''}"><div class="ic">${ic||''}</div><div><small>${label}</small><b>${val}</b>${sub?`<span>${sub}</span>`:''}</div></div>`}

/* ---- modal ---- */
function openModal(h,cls=''){$('#modal-root').innerHTML=`<div class="ov" data-act="ovl"><div class="mod ${cls}" role="dialog" aria-modal="true">${h}</div></div>`;$('#modal-root input:not([type=hidden]),#modal-root select')?.focus({preventScroll:true})}
function closeModal(){$('#modal-root').innerHTML=''}
const mErr=(id,t)=>{$(id).innerHTML=`<div class="err">${esc(t)}</div>`};
addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});

/* ---- aksi bersama ---- */
ACT.logout=()=>api('logout').then(async()=>{await sync().catch(()=>{});go('/masuk');route()});
ACT.menu=()=>$('#shell')?.classList.toggle('open');
ACT.umenu=()=>$('#umenu')?.classList.toggle('on');
ACT.close=closeModal;
ACT.eye=(id,t)=>{const i=$('input',t.parentElement);i.type=i.type==='password'?'text':'password';t.textContent=i.type==='password'?'Lihat':'Sembunyi'};
ACT.bell=()=>{const u=me();let it;
 if(u.role==='pelanggan')it=db.orders.slice().sort((a,b)=>b.n-a.n).slice(0,8).map(o=>[`#${oid(o.n)} • ${o.status}`,`${o.sname} ${o.kg} kg`,o.t]);
 else it=db.log.slice(0,8).map(l=>[l.x,'',l.t]);
 openModal(`<button class="x" data-act="close" aria-label="Tutup">✕</button><h3>Notifikasi</h3><div style="margin:14px 0">${it.length?`<ul class="log">${it.map(i=>`<li>${esc(i[0])}${i[1]?' <span style="color:var(--mut)">• '+esc(i[1])+'</span>':''}<small>${fmtD(i[2])} ${fmtT(i[2])}</small></li>`).join('')}</ul>`:empty('Belum ada notifikasi','Pembaruan akan muncul di sini.')}</div><button class="btn block ghost" data-act="close">Tutup</button>`)};
document.addEventListener('click',e=>{
 if(!e.target.closest('.user-wrap'))$('#umenu')?.classList.remove('on');
 const t=e.target.closest('[data-act],[data-nav]');if(!t)return;const d=t.dataset;
 if(d.act==='ovl'){if(e.target===t)closeModal();return}
 if(d.nav){go('/app/'+d.nav);return}
 ACT[d.act]?.(d.id,t);
 if(d.act!=='umenu')$('#umenu')?.classList.remove('on');
 if(d.act!=='menu')$('#shell')?.classList.remove('open');
});
