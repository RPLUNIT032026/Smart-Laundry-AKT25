'use strict';
/* Mulai aplikasi, jam mesin, dan penyegaran data otomatis */
setInterval(()=>{
 $$('[data-m]').forEach(el=>{const m=db.machines.find(m=>m.id==el.dataset.m);if(!m)return;el.textContent=clock(mRem(m));const b=$(`[data-b="${el.dataset.m}"]`);if(b)b.style.width=(100-mRem(m)/(m.dur*600))+'%'});
 TICK.forEach(f=>f());
},1000);
setInterval(async()=>{
 const u=me();if(!u||document.hidden||u.auto_refresh===0)return;
 const prevN=db.orders.length,prevS=db.orders.map(o=>o.status).join();
 try{
  if(!await sync())return;
  const nu=me();if(!nu)return route();
  if(nu.role==='petugas'&&nu.notif_queue&&db.orders.length>prevN)toast('Ada pesanan baru di antrean');
  else if(nu.role==='pelanggan'&&db.orders.map(o=>o.status).join()!==prevS)toast('Status pesananmu diperbarui');
  if($('.ov')||/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName)||location.hash.includes('pengaturan'))return;
  route();
 }catch(e){}
},15000);
addEventListener('storage',e=>{if(e.key===LS_KEY||e.key===SESS_KEY)sync().then(c=>{if(c&&!$('.ov')&&!/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName||''))route()}).catch(()=>{})});
try{
 if(!location.hash||location.hash==='#')location.hash='/masuk';
 sync().then(route).catch(e=>{console.error(e);fatal(e)});
}catch(e){console.error(e);fatal(e)}
