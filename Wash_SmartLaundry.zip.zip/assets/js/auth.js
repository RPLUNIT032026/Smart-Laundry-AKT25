'use strict';
/* Login (Owner / Petugas / Customer), daftar Customer, lupa sandi, dan halaman info */
let loginRole=sessionStorage.getItem('ww_role')||'pelanggan';
const ROLE_TAB=[['owner','Owner'],['petugas','Petugas'],['pelanggan','Customer']];
function authShell(inner){return `<div class="auth"><section class="auth-l"><span class="tw">smart laundry digital twin</span><div class="brand">WASH WASH<br>LAUNDRY</div><h1>Cucian beres.<br>tinggal santai.</h1>
<p>Selamat datang di wash wash laundry!<br>Pesan layanan dan pantau cucian lewat satu akun.<br>Biar urusan baju kotor nggak memenuhi harimu.</p>
<div class="feat"><div><b>Pesan lebih praktis</b><span>Pilih layanan laundry sesuai kebutuhanmu.</span></div><div><b>Riwayat tetap rapi</b><span>Lihat kembali pesanan tanpa perlu cari di chat.</span></div></div>
<img class="logo-big" src="assets/img/logo-washwash.png" alt="Wash Wash Laundry"><div class="bot"><b>Masuk dulu, sisanya lebih mudah.</b><p>Pesanan dan riwayat laundry kamu, dalam satu akun.</p></div></section>
<section class="auth-r"><div class="auth-top">Butuh bantuan? <a href="#/bantuan">Hubungi kami</a></div><div class="auth-card"><img class="m-logo" src="assets/img/logo-washwash.png" alt="Wash Wash Laundry">${inner}</div>
<div class="auth-foot"><div><a href="#/kebijakan">Kebijakan Privasi</a><a href="#/syarat">Syarat &amp; Ketentuan</a></div><div>© ${new Date().getFullYear()} Smart Laundry. Semua hak dilindungi.</div></div></section></div>`}
const pwField=(n,l,ph,ac)=>`<div class="field"><label>${l}</label><div class="pw"><input class="inp" name="${n}" type="password" placeholder="${ph}" autocomplete="${ac}" required><a data-act="eye">Lihat</a></div></div>`;
function authPage(mode){
 const cust=loginRole==='pelanggan',remembered=localStorage.getItem('ww_email')||'';
 const F={
 masuk:`<h2>Selamat datang kembali</h2><p>Masuk untuk ${cust?'pesan layanan dan pantau cucianmu.':loginRole==='petugas'?'mengelola antrean dan mesin.':'memantau bisnis laundry.'}</p>
 <div class="tabs3" role="tablist">${ROLE_TAB.map(([k,l])=>`<button type="button" role="tab" class="tab ${k===loginRole?'on':''}" data-act="role" data-id="${k}">${l}</button>`).join('')}</div>
 <form id="f" novalidate><div id="msg"></div>
 <div class="field"><label>Email</label><input class="inp" name="email" type="email" placeholder="nama@email.com" autocomplete="email" value="${esc(remembered)}" required></div>
 ${pwField('pw','Kata sandi','Masukkan kata sandi','current-password')}
 <div class="row"><label><input type="checkbox" name="rem" ${remembered?'checked':''}> Ingat saya</label>${cust?'<a href="#/lupa">Lupa kata sandi?</a>':`<span>Lupa sandi? Hubungi ${loginRole==='petugas'?'owner':'administrator'}</span>`}</div>
 <button class="btn block">Masuk sebagai ${ROLE_TAB.find(t=>t[0]===loginRole)[1]}</button></form>
 <p class="alt">Belum punya akun? <a href="#/daftar">Daftar sekarang</a></p>`,
 daftar:`<h2>Buat akun baru</h2><p>Pilih jenis akun, lalu isi data. Petugas & Owner membutuhkan kode keamanan.</p>
 <div class="tabs3" role="tablist">${ROLE_TAB.map(([k,l])=>`<button type="button" role="tab" class="tab ${k===loginRole?'on':''}" data-act="role-daftar" data-id="${k}">${l}</button>`).join('')}</div>
 <form id="f" novalidate><div id="msg"></div>
 <div class="field"><label>Nama lengkap</label><input class="inp" name="name" autocomplete="name" required></div>
 <div class="field"><label>Email</label><input class="inp" name="email" type="email" autocomplete="email" placeholder="nama@email.com" required></div>
 ${pwField('pw','Kata sandi (min. 6 karakter)','Buat kata sandi','new-password')}
 <div class="field"><label>Ulangi kata sandi</label><input class="inp" name="pw2" type="password" autocomplete="new-password" required></div>
 ${loginRole!=='pelanggan'?`<div class="field"><label>Kode keamanan ${loginRole==='petugas'?'Petugas':'Owner'}</label><input class="inp" name="kode" type="text" placeholder="Masukkan kode keamanan" autocomplete="off" autocapitalize="characters" spellcheck="false" required></div>`:''}
 <label class="agree"><input type="checkbox" name="agree"> Saya setuju dengan <a href="#/syarat">Syarat &amp; Ketentuan</a> dan <a href="#/kebijakan">Kebijakan Privasi</a></label>
 <button class="btn block">Daftar sebagai ${ROLE_TAB.find(t=>t[0]===loginRole)[1]}</button></form><p class="alt">Sudah punya akun? <a href="#/masuk">Masuk</a></p>`,
 lupa:`<h2>Atur ulang kata sandi</h2><p>Khusus akun Customer. Masukkan email lalu buat kata sandi baru.</p><form id="f" novalidate><div id="msg"></div>
 <div class="field"><label>Email terdaftar</label><input class="inp" name="email" type="email" required></div>
 ${pwField('pw','Kata sandi baru','Minimal 6 karakter','new-password')}
 <div class="field"><label>Ulangi kata sandi baru</label><input class="inp" name="pw2" type="password" autocomplete="new-password" required></div>
 <button class="btn block">Simpan kata sandi baru</button></form><p class="alt"><a href="#/masuk">Kembali ke halaman masuk</a></p>`};
 $('#app').innerHTML=authShell(F[mode]);
 $('#f').onsubmit=async e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target)),email=(d.email||'').trim().toLowerCase(),fail=t=>mErr('#msg',t);
  if(!/^\S+@\S+\.\S+$/.test(email))return fail('Format email belum benar.');
  if(mode==='masuk'&&!d.pw)return fail('Kata sandi wajib diisi.');
  if(mode!=='masuk'){if((d.pw||'').length<6)return fail('Kata sandi minimal 6 karakter.');if(d.pw!==d.pw2)return fail('Ulangi kata sandi tidak sama.')}
  if(mode==='daftar'){if(!(d.name||'').trim())return fail('Nama lengkap wajib diisi.');if(!d.agree)return fail('Centang persetujuan syarat & kebijakan.')}
  const btn=$('button.btn',e.target);btn.disabled=true;
  const r=await api({masuk:'login',daftar:'register',lupa:'reset'}[mode],{name:d.name,email,pw:d.pw,role:loginRole,kode:d.kode||'',rem:!!d.rem});btn.disabled=false;
  if(r.error)return fail(r.error);
  if(mode==='lupa'){toast('Kata sandi diperbarui. Silakan masuk.');return go('/masuk')}
  if(mode==='masuk'){d.rem?localStorage.setItem('ww_email',email):localStorage.removeItem('ww_email')}
  try{await sync()}catch(x){return fatal(x)}
  toast(mode==='daftar'?'Akun berhasil dibuat':'Berhasil masuk');go('/app/dashboard');route()};
}
ACT.role=id=>{loginRole=id;sessionStorage.setItem('ww_role',id);authPage('masuk')};
ACT['role-daftar']=id=>{loginRole=id;sessionStorage.setItem('ww_role',id);authPage('daftar')};

function docPage(k){
 const D={kebijakan:['Kebijakan Privasi',[['Data yang kami simpan','Nama, email, nomor HP, alamat, foto profil (jika kamu unggah), dan riwayat pesanan laundry.'],['Cara data digunakan','Hanya untuk memproses pesanan, menampilkan status cucian, mengirim pemberitahuan sesuai pengaturanmu, dan membuat laporan layanan.'],['Keamanan','Kata sandi disimpan dalam bentuk hash dan tidak pernah ditampilkan. Setiap peran hanya bisa mengakses menu yang sesuai. Data aplikasi ini tersimpan di browser perangkat yang kamu pakai.'],['Hak kamu','Kamu dapat mengubah data profil kapan saja di menu Pengaturan, atau meminta penghapusan akun lewat halaman Bantuan.']]],
 syarat:['Syarat & Ketentuan',[['Layanan','Tarif dihitung per kilogram sesuai layanan yang dipilih. Berat final ditimbang saat cucian diterima.'],['Pembayaran','Pembayaran QRIS dilakukan di awal dan berlaku 15 menit sebelum perlu diterbitkan ulang. Bayar di tempat dilakukan saat cucian diambil.'],['Pembatalan','Pesanan dapat dibatalkan selama masih berstatus Menunggu Antrean.'],['Tanggung jawab','Mohon keluarkan barang berharga dari pakaian sebelum diserahkan. Pisahkan pakaian putih dan berwarna.'],['Akun','Akun Customer dibuat sendiri. Akun Petugas membutuhkan kode keamanan WASHSTAFF2026. Akun Owner membutuhkan kode keamanan WASHOWNER2026. Owner juga dapat mengelola petugas di Manajemen Karyawan.']]],
 bantuan:['Bantuan',[['Lupa kata sandi?','Customer: pilih "Lupa kata sandi?" di halaman masuk. Petugas: minta Owner mengatur ulang sandi lewat Manajemen Karyawan.'],['Cara membuat pesanan','Masuk sebagai Customer, tekan Buat Pesanan Baru, pilih layanan dan berat, lalu kirim. Bayar lewat QRIS atau di tempat.'],['Cara melacak cucian','Buka menu Pantau / Lacak Status untuk melihat tahap cucianmu dan struk pembayaran.']]]}[k];
 $('#app').innerHTML=`<div class="doc"><div class="doc-top"><img src="assets/img/logo-icon.png" alt="Wash Wash Laundry"><a href="javascript:history.back()">← Kembali</a></div><h1>${D[0]}</h1>${D[1].map(s=>`<h3>${s[0]}</h3><p>${s[1]}</p>`).join('')}
 ${k==='bantuan'?'<h3>Hubungi kami</h3><div id="contact"><p>Memuat kontak…</p></div>':''}</div>`;
 if(k==='bantuan')api('info').then(r=>{$('#contact')&&($('#contact').innerHTML=`<p><b>${esc(r.name||'Wash Wash Laundry')}</b><br>WhatsApp: ${r.wa?`<a href="https://wa.me/${esc(r.wa.replace(/\D/g,'').replace(/^0/,'62'))}">${esc(r.wa)}</a>`:'belum diatur owner'}<br>Alamat: ${esc(r.addr||'belum diatur owner')}<br>Jam operasional: ${esc(r.hours||'-')}</p>`)}).catch(()=>{});
}
