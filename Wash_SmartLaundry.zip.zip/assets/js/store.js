'use strict';
/* Wash Wash Laundry - penyimpanan lokal (pengganti server PHP/MySQL).
   Semua data tersimpan di localStorage browser ini. Aturan hak akses sama seperti server:
   setiap aksi dicek berdasarkan peran akun yang sedang login. */
const LS_KEY='ww_db_v4',SESS_KEY='ww_session';
const S_FLOW=['Dibuat','Menunggu Antrean','Diproses Mesin','Siap Diambil','Telah Diambil'];
const S_ROLES={pelanggan:'Customer',petugas:'Petugas',owner:'Owner'};
const SHA_K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
/* SHA-256 murni JS (tetap jalan di file:// tanpa konteks aman) */
function sha256(s){
 const by=new TextEncoder().encode(s),l=by.length,n=((l+9+63)>>6)<<6,b=new Uint8Array(n);
 b.set(by);b[l]=0x80;const dv=new DataView(b.buffer);dv.setUint32(n-4,(l*8)>>>0);dv.setUint32(n-8,Math.floor(l*8/4294967296));
 let h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];const w=new Uint32Array(64);
 for(let i=0;i<n;i+=64){
  for(let j=0;j<16;j++)w[j]=dv.getUint32(i+j*4);
  for(let j=16;j<64;j++){const a=w[j-15],c=w[j-2],s0=((a>>>7)|(a<<25))^((a>>>18)|(a<<14))^(a>>>3),s1=((c>>>17)|(c<<15))^((c>>>19)|(c<<13))^(c>>>10);w[j]=(w[j-16]+s0+w[j-7]+s1)|0}
  let [a,b2,c,d,e,f,g,hh]=h;
  for(let j=0;j<64;j++){const S1=((e>>>6)|(e<<26))^((e>>>11)|(e<<21))^((e>>>25)|(e<<7)),ch=(e&f)^(~e&g),t1=(hh+S1+ch+SHA_K[j]+w[j])|0,S0=((a>>>2)|(a<<30))^((a>>>13)|(a<<19))^((a>>>22)|(a<<10)),mj=(a&b2)^(a&c)^(b2&c),t2=(S0+mj)|0;hh=g;g=f;f=e;e=(d+t1)|0;d=c;c=b2;b2=a;a=(t1+t2)|0}
  h=[h[0]+a,h[1]+b2,h[2]+c,h[3]+d,h[4]+e,h[5]+f,h[6]+g,h[7]+hh].map(x=>x|0)}
 return h.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('')}
const randHex=n=>{const a=new Uint8Array(n);try{(self.crypto||{}).getRandomValues(a)}catch(e){for(let i=0;i<n;i++)a[i]=Math.random()*256}return [...a].map(x=>x.toString(16).padStart(2,'0')).join('')};
const hashPw=(pw,salt)=>{let h=sha256(salt+':'+pw);for(let i=0;i<10000;i++)h=sha256(h+salt+pw);return h};
/* penyimpanan */
const ss={get:k=>{try{return sessionStorage.getItem(k)}catch(e){return null}},set:(k,v)=>{try{sessionStorage.setItem(k,v)}catch(e){}}};
const sGet=k=>{try{return sessionStorage.getItem(k)||localStorage.getItem(k)}catch(e){return null}};
const sSet=(k,v,rem)=>{try{sessionStorage.removeItem(k);localStorage.removeItem(k);(rem?localStorage:sessionStorage).setItem(k,v)}catch(e){}};
const sDel=k=>{try{sessionStorage.removeItem(k);localStorage.removeItem(k)}catch(e){}};
let MEM=null;
function dbRead(){let raw=null;try{raw=localStorage.getItem(LS_KEY)}catch(e){raw=MEM}
 if(raw){try{const d=JSON.parse(raw);if(d&&Array.isArray(d.users))return d}catch(e){}}return null}
function dbWrite(d){const s=JSON.stringify(d);MEM=s;try{localStorage.setItem(LS_KEY,s)}catch(e){return false}return true}
function seedDB(){
 /* Mulai kosong: tidak ada akun dummy. User daftar sendiri.
    Petugas butuh kode WASHSTAFF2026, Owner butuh WASHOWNER2026. */
 const d={users:[],
 services:[{id:'s1',name:'Reguler',tag:'Paket harian',price:7000,est:'2 hari',desc:'Bersih dan kering untuk keseharian.',feat:['Cuci + pengeringan mesin','Dilipat rapi, tanpa setrika','Dipantau otomatis melalui IoT'],on:true},
  {id:'s2',name:'Ekspres',tag:'Prioritas cepat',price:12000,est:'1 hari',desc:'Cucian mendesak, tetap maksimal.',feat:['Cuci + pengeringan mesin','Antrean proses diprioritaskan','Dilipat rapi, tanpa setrika'],on:true},
  {id:'s3',name:'Cuci Basah',tag:'Paket hemat',price:5000,est:'6 jam',desc:'Cuci bersih, jemur sendiri di rumah.',feat:['Proses pencucian mesin','Tanpa pengeringan & setrika','Cocok untuk dijemur mandiri'],on:true}],
 machines:[[1,'Mesin 01',15],[2,'Mesin 02',15],[3,'Mesin 03',15],[4,'Mesin 04',20]].map(m=>({id:m[0],name:m[1],type:'Front load',cap:m[2],status:'idle',active:1,orderId:null,start:null,dur:0,cycles:0,totalMin:0})),
 orders:[],logs:[],settings:{biz_name:'Wash Wash Laundry',biz_addr:'',biz_wa:'',biz_hours:'08.00 - 21.00'},seq:{user:0,order:0,machine:4}};
 try{dbWrite(d)}catch(e){}
 return d}

/* "Server" lokal: dipanggil sama seperti API sebelumnya */
function LocalAPI(a,inp){
 inp=inp||{};let d=dbRead()||seedDB();let actor=null,res;
 const ms=()=>Date.now(),oidS=n=>'WW-'+String(n).padStart(4,'0'),fail=m=>{throw{error:m}};
 const str=(k,m=255)=>String(inp[k]??'').trim().slice(0,m),flag=k=>inp[k]?1:0,okEmail=e=>/^\S+@\S+\.\S+$/.test(e)&&e.length<=150;
 const cur=()=>{const id=+(sGet(SESS_KEY)||0),u=d.users.find(x=>x.id===id);if(!u||!u.active){if(id)sDel(SESS_KEY);return null}return u};
 const pub=u=>({id:u.id,name:u.name,email:u.email,role:u.role,phone:u.phone,address:u.address,note:u.note,shift:u.shift,photo:u.photo,notif_wa:u.notif_wa,notif_email:u.notif_email,notif_queue:u.notif_queue,auto_refresh:u.auto_refresh,default_pay:u.default_pay,active:u.active});
 const need=roles=>{const u=cur();if(!u)fail('Silakan masuk dulu.');if(roles&&!roles.includes(u.role))fail('Aksi tidak diizinkan untuk peran ini.');actor=u.name;return u};
 const lg=t=>{d.logs.unshift({t:ms(),x:(t+(actor?' • '+actor:'')).slice(0,255)});d.logs=d.logs.slice(0,100)};
 const emailTaken=(e,ex=0)=>d.users.some(x=>x.email===e&&x.id!==ex);
 const getOrder=n=>d.orders.find(o=>o.n===+n)||fail('Pesanan tidak ditemukan.');
 const markPaid=(o,rec,chg)=>{o.paid=1;o.paidAt=ms();o.received=rec;o.changeAmt=chg};
 const newRef=()=>'QR'+new Date().toISOString().slice(2,10).replace(/-/g,'')+randHex(3).toUpperCase();
 const newUser=(o)=>{const salt=randHex(8);return{id:++d.seq.user,phone:'',address:'',note:'',shift:'pagi',photo:null,notif_wa:1,notif_email:1,notif_queue:1,auto_refresh:1,default_pay:'qris',active:1,created:ms(),salt,...o}};
 const makeOrder=(uid,cust,creator)=>{
  const sv=d.services.find(s=>s.id===inp.sid&&s.on);if(!sv)fail('Layanan tidak tersedia.');
  const max=creator==='pelanggan'?15:30,kg=Math.max(1,Math.min(max,parseInt(inp.kg)||1)),pay=inp.pay==='cod'?'cod':'qris',now=ms();
  const o={n:++d.seq.order,uid,cust,sid:sv.id,sname:sv.name,kg,total:sv.price*kg,pay,paid:0,pref:inp.mid?+inp.mid:null,note:str('note'),status:'Menunggu Antrean',t:now,paidAt:null,ref:pay==='qris'?newRef():null,qrisExp:pay==='qris'?now+900000:null,received:null,changeAmt:null,handledBy:null};
  d.orders.push(o);lg('Pesanan baru #'+oidS(o.n)+' • '+cust);return o};
 const machOf=n=>d.machines.find(m=>m.orderId===n);
 switch(a){
 case 'info':{const s=d.settings;return{name:s.biz_name||'Wash Wash Laundry',addr:s.biz_addr||'',wa:s.biz_wa||'',hours:s.biz_hours||''}}
 /* --- auth --- */
 case 'register':{const name=str('name',100),email=str('email',150).toLowerCase(),pw=String(inp.pw??'');
  const role=['pelanggan','petugas','owner'].includes(inp.role)?inp.role:'pelanggan';
  const kode=String(inp.kode||'').trim().toUpperCase();
  if(!name)fail('Nama lengkap wajib diisi.');if(!okEmail(email))fail('Format email belum benar.');if(pw.length<6)fail('Kata sandi minimal 6 karakter.');if(emailTaken(email))fail('Email sudah terdaftar. Silakan masuk.');
  if(role==='petugas'){if(!kode)fail('Peran Petugas memerlukan kode keamanan.');if(kode!=='WASHSTAFF2026')fail('Kode keamanan petugas tidak valid.');}
  if(role==='owner'){if(!kode)fail('Peran Owner memerlukan kode keamanan.');if(kode!=='WASHOWNER2026')fail('Kode keamanan owner tidak valid.');}
  const tmp=newUser({name,email,role});tmp.pw=hashPw(pw,tmp.salt);d.users.push(tmp);sSet(SESS_KEY,String(tmp.id),false);res={ok:1};break}
 case 'login':{const role=inp.role,email=str('email',150).toLowerCase(),pw=String(inp.pw??'');
  if(!S_ROLES[role])fail('Pilih jenis akun: Owner, Petugas, atau Customer.');
  if(+(ss.get('ww_lock')||0)>ms())fail('Terlalu banyak percobaan gagal. Coba lagi dalam beberapa menit.');
  if(!okEmail(email))fail('Format email belum benar.');if(!pw)fail('Kata sandi wajib diisi.');
  const u=d.users.find(x=>x.email===email);
  if(!u||u.pw!==hashPw(pw,u.salt)){let f=+(ss.get('ww_fails')||0)+1;if(f>=5){ss.set('ww_lock',String(ms()+300000));f=0}ss.set('ww_fails',String(f));fail('Email atau kata sandi salah.')}
  if(u.role!==role)fail('Akun ini bukan akun '+S_ROLES[role]+'. Pilih jenis akun yang sesuai.');
  if(!u.active)fail('Akun dinonaktifkan. Hubungi owner.');
  ss.set('ww_fails','0');sSet(SESS_KEY,String(u.id),!!inp.rem);res={ok:1};break}
 case 'logout':sDel(SESS_KEY);return{ok:1};
 case 'reset':{const email=str('email',150).toLowerCase(),pw=String(inp.pw??'');
  if(!okEmail(email))fail('Format email belum benar.');if(pw.length<6)fail('Kata sandi minimal 6 karakter.');
  const u=d.users.find(x=>x.email===email&&x.role==='pelanggan');if(!u)fail('Email Customer tidak ditemukan. Akun Petugas/Owner direset oleh Owner.');
  u.salt=randHex(8);u.pw=hashPw(pw,u.salt);res={ok:1};break}
 /* --- state --- */
 case 'state':{const u=cur(),r={user:u?pub(u):null,orders:[],services:[],machines:[],log:[],staff:[],settings:{},room:{waiting:0,running:0,ready:0}};if(!u)return r;
  r.services=d.services.map(s=>({...s,feat:[...s.feat]}));r.machines=d.machines.filter(m=>u.role==='owner'||m.active).map(m=>({...m}));
  r.orders=d.orders.filter(o=>u.role!=='pelanggan'||o.uid===u.id).map(o=>({...o,hname:o.handledBy?(d.users.find(x=>x.id===o.handledBy)||{}).name||null:null}));
  d.orders.forEach(o=>{const k={'Menunggu Antrean':'waiting','Diproses Mesin':'running','Siap Diambil':'ready'}[o.status];if(k)r.room[k]++});
  r.settings={...d.settings};if(u.role!=='pelanggan')r.log=d.logs.slice(0,60);
  if(u.role==='owner')r.staff=d.users.filter(x=>x.role==='petugas').map(x=>({id:x.id,name:x.name,email:x.email,phone:x.phone,shift:x.shift,active:x.active,created:x.created}));
  return r}
 /* --- profil & akun --- */
 case 'profile':{const u=need();const set={};
  if('name' in inp){const n=str('name',100);if(!n)fail('Nama wajib diisi.');set.name=n}
  if('email' in inp){const e=str('email',150).toLowerCase();if(!okEmail(e))fail('Format email belum benar.');if(emailTaken(e,u.id))fail('Email sudah dipakai akun lain.');set.email=e}
  if('phone' in inp)set.phone=str('phone',30);if('note' in inp)set.note=str('note',255);
  if('address' in inp&&u.role==='pelanggan')set.address=str('address',255);
  ['notif_wa','notif_email','notif_queue','auto_refresh'].forEach(k=>{if(k in inp)set[k]=flag(k)});
  if('default_pay' in inp&&u.role==='pelanggan')set.default_pay=inp.default_pay==='cod'?'cod':'qris';
  Object.assign(u,set);if(set.name)d.orders.forEach(o=>{if(o.uid===u.id)o.cust=set.name});res={ok:1};break}
 case 'changepw':{const u=need(),pw=String(inp.pw??'');if(pw.length<6)fail('Kata sandi baru minimal 6 karakter.');
  if(u.pw!==hashPw(String(inp.old??''),u.salt))fail('Kata sandi lama salah.');u.salt=randHex(8);u.pw=hashPw(pw,u.salt);res={ok:1};break}
 case 'photo':{const u=need(),dt=String(inp.data??'');
  if(dt===''){u.photo=null}else{if(!/^data:image\/(jpeg|png|webp);base64,/.test(dt))fail('Format foto harus JPG, PNG, atau WebP.');if(dt.length>400000)fail('Foto terlalu besar.');u.photo=dt}
  res={ok:1};break}
 case 'bizsave':{need(['owner']);[['biz_name',80],['biz_addr',200],['biz_wa',30],['biz_hours',60]].forEach(([k,m])=>{if(k in inp)d.settings[k]=str(k,m)});res={ok:1};break}
 /* --- pesanan & pembayaran --- */
 case 'order':{const u=need(['pelanggan']);res={ok:1,n:makeOrder(u.id,u.name,'pelanggan').n};break}
 case 'walkin':{need(['petugas','owner']);const o=makeOrder(null,str('cust',100)||'Pelanggan umum','staff'),rec=parseInt(inp.received)||0;
  if(o.pay==='cod'&&rec>0){if(rec<o.total)fail('Uang diterima kurang dari total.');markPaid(o,rec,rec-o.total);lg('Pembayaran tunai #'+oidS(o.n)+' diterima')}res={ok:1,n:o.n};break}
 case 'payconfirm':{const u=need(),o=getOrder(inp.n);
  if(u.role==='pelanggan'&&o.uid!==u.id)fail('Bukan pesananmu.');
  if(o.pay!=='qris'||o.paid||o.status==='Dibatalkan')fail('Pesanan ini tidak menunggu pembayaran QRIS.');
  if(u.role==='pelanggan'&&o.qrisExp<ms())fail('QRIS sudah kedaluwarsa. Terbitkan ulang QRIS.');
  markPaid(o,o.total,0);lg('Pembayaran QRIS #'+oidS(o.n)+' lunas');res={ok:1};break}
 case 'qrisreissue':{const u=need(),o=getOrder(inp.n);if(u.role==='pelanggan'&&o.uid!==u.id)fail('Bukan pesananmu.');
  if(o.pay!=='qris'||o.paid||o.status==='Dibatalkan')fail('QRIS tidak bisa diterbitkan ulang.');o.ref=newRef();o.qrisExp=ms()+900000;res={ok:1};break}
 case 'paycash':{need(['petugas','owner']);const o=getOrder(inp.n),rec=parseInt(inp.received)||0;
  if(o.paid||o.status==='Dibatalkan')fail('Pesanan sudah lunas atau dibatalkan.');if(rec<o.total)fail('Uang diterima kurang dari total.');
  o.pay='cod';markPaid(o,rec,rec-o.total);lg('Pembayaran tunai #'+oidS(o.n)+' diterima');res={ok:1};break}
 case 'cancel':{const u=need(['pelanggan']),o=getOrder(inp.n);if(o.uid!==u.id||o.status!=='Menunggu Antrean')fail('Pesanan tidak bisa dibatalkan.');
  o.status='Dibatalkan';lg('#'+oidS(o.n)+' dibatalkan pelanggan');res={ok:1};break}
 case 'start':{const u=need(['petugas','owner']),o=getOrder(inp.n),dur=Math.max(1,Math.min(240,parseInt(inp.dur)||30));
  if(o.status!=='Menunggu Antrean')fail('Pesanan tidak ada di antrean.');if(o.pay==='qris'&&!o.paid)fail('Pesanan QRIS belum dibayar.');
  const m=d.machines.find(x=>x.id===+inp.mid&&x.active&&x.status==='idle'&&x.orderId==null);if(!m)fail('Mesin tidak tersedia (sedang dipakai atau perbaikan).');
  if(o.kg>m.cap)fail('Berat cucian melebihi kapasitas '+m.name+' ('+m.cap+' kg).');
  Object.assign(m,{orderId:o.n,start:ms(),dur});o.status='Diproses Mesin';o.handledBy=u.id;lg(m.name+' mulai mencuci #'+oidS(o.n));res={ok:1};break}
 case 'next':{const u=need(['petugas','owner']),o=getOrder(inp.n),i=S_FLOW.indexOf(o.status);
  if(i<2||i>=4)fail('Status tidak bisa dilanjutkan.');if(i===3&&!o.paid)fail('Pembayaran belum lunas. Terima pembayaran dulu.');
  o.status=S_FLOW[i+1];if(!o.handledBy)o.handledBy=u.id;
  if(i===2){const m=machOf(o.n);if(m){m.cycles++;m.totalMin+=m.dur;Object.assign(m,{orderId:null,start:null,dur:0});lg(m.name+' selesai • #'+oidS(o.n))}}else lg('#'+oidS(o.n)+' telah diambil');
  res={ok:1};break}
 /* --- mesin --- */
 case 'machine_status':{need(['petugas','owner']);const st=inp.status;if(!['idle','maintenance'].includes(st))fail('Status tidak valid.');
  const m=d.machines.find(x=>x.id===+inp.id)||fail('Mesin tidak ditemukan.');if(m.orderId)fail('Mesin sedang mencuci. Tunggu sampai selesai.');
  m.status=st;lg(m.name+(st==='maintenance'?' masuk perbaikan':' kembali siaga'));res={ok:1};break}
 case 'machine_save':{need(['owner']);const id=+inp.id||0,name=str('name',40),type=str('type',40)||'Front load',cap=parseInt(inp.cap)||0;
  if(!name)fail('Nama mesin wajib diisi.');if(cap<1||cap>50)fail('Kapasitas harus 1 - 50 kg.');
  if(id){const m=d.machines.find(x=>x.id===id)||fail('Mesin tidak ditemukan.');Object.assign(m,{name,type,cap})}
  else d.machines.push({id:++d.seq.machine,name,type,cap,status:'idle',active:1,orderId:null,start:null,dur:0,cycles:0,totalMin:0});
  lg('Konfigurasi mesin '+name+' disimpan');res={ok:1};break}
 case 'machine_toggle':{need(['owner']);const m=d.machines.find(x=>x.id===+inp.id)||fail('Mesin tidak ditemukan.');if(m.orderId)fail('Mesin sedang dipakai.');m.active=m.active?0:1;res={ok:1};break}
 /* --- layanan --- */
 case 'savesvc':{need(['owner']);const f={name:str('name',80),tag:str('tag',80),price:Math.max(500,parseInt(inp.price)||0),est:str('est',40),desc:str('desc',200),feat:(Array.isArray(inp.feat)?inp.feat:[]).map(x=>String(x).trim()).filter(Boolean)};
  if(!f.name)fail('Nama layanan wajib diisi.');
  if(inp.id){const s=d.services.find(x=>x.id===inp.id)||fail('Layanan tidak ditemukan.');Object.assign(s,f)}else d.services.push({id:'s'+ms(),on:true,...f});res={ok:1};break}
 case 'togsvc':{need(['owner']);const s=d.services.find(x=>x.id===inp.id)||fail('Layanan tidak ditemukan.');s.on=!s.on;res={ok:1};break}
 /* --- manajemen karyawan --- */
 case 'staff_save':{need(['owner']);const id=+inp.id||0,name=str('name',100),email=str('email',150).toLowerCase(),phone=str('phone',30),pw=String(inp.pw??''),shift=['pagi','siang','malam'].includes(inp.shift)?inp.shift:'pagi';
  if(!name)fail('Nama petugas wajib diisi.');if(!okEmail(email))fail('Format email belum benar.');if(emailTaken(email,id))fail('Email sudah dipakai akun lain.');
  if((!id||pw!=='')&&pw.length<6)fail('Kata sandi minimal 6 karakter.');
  if(id){const p=d.users.find(x=>x.id===id&&x.role==='petugas')||fail('Petugas tidak ditemukan.');Object.assign(p,{name,email,phone,shift});if(pw){p.salt=randHex(8);p.pw=hashPw(pw,p.salt)}lg('Data petugas '+name+' diubah')}
  else{const p=newUser({name,email,phone,shift,role:'petugas'});p.pw=hashPw(pw,p.salt);d.users.push(p);lg('Petugas baru '+name+' ditambahkan')}
  res={ok:1};break}
 case 'staff_toggle':{need(['owner']);const p=d.users.find(x=>x.id===+inp.id&&x.role==='petugas')||fail('Petugas tidak ditemukan.');
  lg('Akun petugas '+p.name+(p.active?' dinonaktifkan':' diaktifkan'));p.active=p.active?0:1;res={ok:1};break}
 /* --- data aplikasi (owner) --- */
 case 'export':{need(['owner']);return{json:JSON.stringify(d)}}
 case 'import':{need(['owner']);let n;try{n=JSON.parse(String(inp.data||''))}catch(e){fail('File cadangan tidak valid.')}
  if(!n||!['users','services','machines','orders','logs'].every(k=>Array.isArray(n[k]))||!n.settings||!n.seq||!n.users.some(u=>u.role==='owner'))fail('File cadangan tidak lengkap.');
  d=n;res={ok:1};break}
 case 'resetall':{need(['owner']);d=seedDB();res={ok:1};break}
 default:fail('Aksi tidak dikenal.')}
 if(!dbWrite(d))fail('Penyimpanan browser penuh atau dinonaktifkan. Hapus foto/data lama atau izinkan penyimpanan situs.');
 return res}
