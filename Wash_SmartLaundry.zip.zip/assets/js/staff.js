'use strict';
/* Fitur Petugas: antrean, mesin, update status, terima pembayaran, catat pesanan walk-in */
let qFilter='';
const queueList=()=>db.orders.filter(o=>!['Telah Diambil','Dibatalkan'].includes(o.status)).sort((a,b)=>a.n-b.n);
function nextBtn(o){
 if(o.status==='Menunggu Antrean')return o.pay==='qris'&&!o.paid?`<button class="btn sm out" data-act="confirmqr" data-id="${o.n}">Konfirmasi lunas</button>`:`<button class="btn sm" data-act="start" data-id="${o.n}">Proses di mesin</button>`;
 if(o.status==='Diproses Mesin')return `<button class="btn sm" data-act="next" data-id="${o.n}">Siap diambil</button>`;
 if(o.status==='Siap Diambil')return o.paid?`<button class="btn sm" data-act="next" data-id="${o.n}">Telah diambil</button>`:`<button class="btn sm out" data-act="cash" data-id="${o.n}">Terima pembayaran</button>`;
 return ''}
function queueRows(list){return list.length?`<table><tr><th>ID Pesanan</th><th>Pelanggan</th><th>Layanan</th><th>Berat</th><th>Masuk</th><th>Status</th><th>Bayar</th><th>Aksi</th></tr>${list.map(o=>`<tr><td><a class="id" data-act="detail" data-id="${o.n}">${oid(o.n)}</a></td><td>${esc(o.cust)}</td><td>${esc(o.sname)}</td><td>${o.kg} kg</td><td>${fmtT(o.t)}</td><td>${badge(o.status)}</td><td>${payBadge(o)}</td><td>${nextBtn(o)}</td></tr>`).join('')}</table>`:empty('Antrean masih kosong','Pesanan pelanggan akan muncul di sini setelah mereka membuatnya.')}
function queue(short,title='Antrean pesanan'){
 let q=queueList();const total=q.length;if(qFilter)q=q.filter(o=>(o.cust+' '+oid(o.n)).toLowerCase().includes(qFilter));if(short)q=q.slice(0,5);
 return `<div class="card"><div class="between wrap"><div><h3>${title}</h3><div class="sub">Layanan cuci kering tanpa setrika</div></div><div class="between" style="gap:8px"><input class="inp sm" id="qsearch" placeholder="Cari nama atau ID pesanan" value="${esc(qFilter)}" style="width:210px">${short&&total>5?'<button class="btn sm out" data-nav="antrean">Lihat semua ›</button>':''}</div></div>
 <div class="tbl" id="qtable">${queueRows(q)}</div><div class="mut small" style="margin-top:10px">Menampilkan ${q.length} dari ${total} pesanan aktif</div></div>`}
document.addEventListener('input',e=>{if(e.target.id!=='qsearch')return;qFilter=e.target.value.trim().toLowerCase();
 let q=queueList().filter(o=>(o.cust+' '+oid(o.n)).toLowerCase().includes(qFilter));if(location.hash.endsWith('dashboard')||location.hash.endsWith('app'))q=q.slice(0,5);$('#qtable').innerHTML=queueRows(q)});
PAGES.petugas.dashboard=u=>{
 const act=db.machines.filter(m=>m.active),run=act.filter(m=>m.orderId).length,td=db.orders.filter(o=>new Date(o.t).toDateString()===new Date().toDateString()).length;
 return `<div class="between wrap"><div><h2 style="font-size:26px">${greet()}, ${esc(u.name.split(' ')[0])}!</h2><p class="mut">Pantau antrean dan proses laundry, semua dalam satu tempat.</p></div>
 <div class="shiftbox"><span class="ic">🕘</span><div><b>${SHIFT[u.shift]}</b><small>${today()}</small></div></div></div>
 <div class="between wrap" style="justify-content:flex-start;gap:10px"><button class="btn" data-act="walkin">＋ Catat Pesanan Pelanggan</button></div>
 <div class="stats">${statCard('Antrean Masuk',db.room.waiting,td+' pesanan hari ini','☰')}${statCard('Diproses Mesin',db.room.running,'Sedang dicuci otomatis','🧺')}${statCard('Siap Diambil',db.room.ready,'Menunggu pelanggan','👜')}${statCard('Mesin Aktif',run+' / '+act.length,act.length?Math.round(run/act.length*100)+'% kapasitas digunakan':'','✓')}</div>
 <div class="card"><div class="between"><div><h3>Monitoring mesin IoT</h3><div class="sub">Digital twin tersinkronisasi dengan kondisi mesin secara real-time.</div></div><span class="badge b-rdy">● MQTT terhubung</span></div>${machCards()}</div>${queue(true)}`};
PAGES.petugas.antrean=()=>queue(false);
PAGES.petugas.mesin=()=>`<div class="card"><h3>Monitoring mesin IoT</h3><div class="sub">Status mesin cuci secara langsung. Mesin berubah otomatis saat pesanan diproses.</div>${machCards()}</div>${logCard()}`;
PAGES.petugas.status=()=>`<div class="card"><h3>Panel kontrol mesin</h3><div class="sub">Atur status operasional mesin. Mesin yang sedang mencuci tidak bisa diubah.</div><div class="tbl">${db.machines.filter(m=>m.active).length?`<table><tr><th>Mesin</th><th>Tipe</th><th>Kapasitas</th><th>Status</th><th>Aksi</th></tr>${db.machines.filter(m=>m.active).map(m=>{const s=mState(m);return `<tr><td><b>${esc(m.name)}</b></td><td>${esc(m.type)}</td><td>${m.cap} kg</td><td><span class="badge ${{run:'b-proc',done:'b-rdy',mnt:'b-x',idle:''}[s]}">${{run:'Mencuci',done:'Selesai',mnt:'Perbaikan',idle:'Tersedia'}[s]}</span></td><td>${m.orderId?'<span class="mut small">Sedang dipakai</span>':s==='mnt'?`<button class="btn sm" data-act="mstatus" data-id="${m.id}" data-st="idle">Set siaga</button>`:`<button class="btn sm out" data-act="mstatus" data-id="${m.id}" data-st="maintenance">Set perbaikan</button>`}</td></tr>`}).join('')}</table>`:empty('Belum ada mesin','Owner perlu menambahkan mesin lebih dulu.')}</div></div>${queue(false,'Update status pesanan')}`;
ACT.mstatus=(id,t)=>act('machine_status',{id:+id,status:t.dataset.st},'Status mesin diperbarui');
ACT.confirmqr=id=>act('payconfirm',{n:+id},'Pembayaran dikonfirmasi lunas');
ACT.next=id=>act('next',{n:+id},'Status diperbarui');
ACT.start=id=>{
 const o=db.orders.find(o=>o.n===+id),free=freeMachines().filter(m=>m.cap>=o.kg);
 if(!free.length)return toast(freeMachines().length?'Tidak ada mesin dengan kapasitas cukup ('+o.kg+' kg).':'Semua mesin sedang dipakai atau perbaikan.');
 const dur=/ekspres/i.test(o.sname)?45:/basah/i.test(o.sname)?30:60;
 openModal(`<button class="x" data-act="close" aria-label="Tutup">✕</button><h3>Proses #${oid(o.n)}</h3><p class="mut" style="margin:8px 0 16px">${esc(o.cust)} • ${esc(o.sname)} ${o.kg} kg</p><form id="sm"><div class="field"><label>Pilih mesin</label><select class="inp" name="m">${free.map(m=>`<option value="${m.id}" ${m.id==o.pref?'selected':''}>${esc(m.name)} · ${m.cap} kg</option>`).join('')}</select></div>
 <div class="field"><label>Durasi (menit)</label><input class="inp" type="number" name="d" min="5" max="240" value="${dur}"></div><div class="acts"><button type="button" class="btn ghost" data-act="close">Batal</button><button class="btn">Mulai</button></div></form>`);
 $('#sm').onsubmit=e=>{e.preventDefault();closeModal();act('start',{n:o.n,mid:+e.target.m.value,dur:+e.target.d.value||30},'Mesin dimulai')}};
ACT.cash=id=>{
 const o=db.orders.find(o=>o.n===+id);
 openModal(`<button class="x" data-act="close" aria-label="Tutup">✕</button><h3>Terima pembayaran</h3><p class="mut small" style="margin:4px 0 12px">#${oid(o.n)} • ${esc(o.cust)}</p><form id="cf"><div id="cm"></div>
 <div class="tot"><div><small>Total tagihan</small></div><b>${rp(o.total)}</b></div>
 <div class="field"><label>Uang diterima (Rp)</label><input class="inp" name="r" type="number" min="${o.total}" step="500" value="${o.total}" required></div>
 <div class="chips"><button type="button" class="chip-b" data-act="rec" data-id="${o.total}">Uang pas</button><button type="button" class="chip-b" data-act="rec" data-id="50000">50.000</button><button type="button" class="chip-b" data-act="rec" data-id="100000">100.000</button></div>
 <div class="tot" style="background:var(--grn)"><div><small>Kembalian</small></div><b id="chg" style="color:var(--grn-d)">Rp0</b></div>
 <div class="acts"><button type="button" class="btn ghost" data-act="close">Batal</button><button class="btn">Konfirmasi lunas</button></div></form>`);
 const f=$('#cf'),upd=()=>{const c=(+f.r.value||0)-o.total;$('#chg').textContent=c>=0?rp(c):'Kurang '+rp(-c)};f.oninput=upd;upd();
 f.onsubmit=async e=>{e.preventDefault();if((+f.r.value||0)<o.total)return mErr('#cm','Uang diterima kurang dari total.');closeModal();const r=await act('paycash',{n:o.n,received:+f.r.value},'Pembayaran tunai diterima');if(!r.error)detailModal(o.n)}};
ACT.rec=id=>{const f=$('#cf');f.r.value=id;f.dispatchEvent(new Event('input'))};
ACT.walkin=()=>{
 const sv=db.services.filter(s=>s.on);if(!sv.length)return toast('Belum ada layanan aktif.');
 openModal(`<button class="x" data-act="close" aria-label="Tutup">✕</button><h3>Catat Pesanan Pelanggan</h3><p class="mut small" style="margin:4px 0 14px">Untuk pelanggan yang datang langsung (tanpa akun).</p><form id="wf2"><div id="wm"></div>
 <div class="field"><label>Nama pelanggan</label><input class="inp" name="cust" maxlength="100" placeholder="Pelanggan umum"></div>
 <div class="field"><label>Layanan</label><select class="inp" name="sid">${sv.map(s=>`<option value="${s.id}">${esc(s.name)} · ${rp(s.price)}/kg</option>`).join('')}</select></div>
 <div class="field"><label>Berat (kg)</label><input class="inp" name="kg" type="number" min="1" max="30" value="3" required></div>
 <div class="field"><label>Metode pembayaran</label><select class="inp" name="pay"><option value="cod">Tunai (bayar di tempat)</option><option value="qris">QRIS</option></select></div>
 <div class="field" id="recf"><label>Uang diterima (opsional, isi jika sudah dibayar)</label><input class="inp" name="r" type="number" min="0" step="500"></div>
 <div class="field"><label>Catatan</label><input class="inp" name="note" maxlength="200"></div>
 <div class="tot"><div><small>Total</small></div><b id="wt"></b></div><div class="acts"><button type="button" class="btn ghost" data-act="close">Batal</button><button class="btn">Simpan pesanan</button></div></form>`);
 const f=$('#wf2'),upd=()=>{$('#wt').textContent=rp(svc(f.sid.value).price*Math.max(1,+f.kg.value||1));$('#recf').style.display=f.pay.value==='cod'?'':'none'};f.oninput=upd;upd();
 f.onsubmit=async e=>{e.preventDefault();const total=svc(f.sid.value).price*Math.max(1,+f.kg.value||1);if(f.pay.value==='cod'&&f.r.value&&+f.r.value<total)return mErr('#wm','Uang diterima kurang dari total.');
  closeModal();const r=await act('walkin',{cust:f.cust.value.trim(),sid:f.sid.value,kg:+f.kg.value,pay:f.pay.value,received:+f.r.value||0,note:f.note.value.trim()},'Pesanan dicatat');
  if(r.n&&f.pay.value==='qris')payModal(r.n)}};
