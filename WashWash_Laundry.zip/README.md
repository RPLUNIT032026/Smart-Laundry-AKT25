# Wash Wash Laundry

**Cara buka:** ekstrak ZIP → klik dua kali file **index.html**
(Tidak perlu Live Server / VS Code / XAMPP)

## Kode keamanan (daftar akun)

| Peran   | Kode            |
|---------|-----------------|
| Petugas | WASHSTAFF2026   |
| Owner   | WASHOWNER2026   |

- Customer daftar tanpa kode
- Email & password dibuat sendiri
- Tidak ada akun dummy

## Struktur yang benar setelah ekstrak
```
(folder hasil ekstrak)/
  index.html          ← klik ini
  README.md
  assets/
    css/style.css
    img/...
    js/...
```

Kalau muncul "Terjadi kesalahan":
1. Pastikan folder `assets` ada di samping `index.html` (jangan pindah index.html sendirian)
2. Buka dengan Google Chrome atau Microsoft Edge
3. Tekan Ctrl+F5 untuk muat ulang paksa
